	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; 2018 Gautam Solar </b> All rights reserved.
		</div>
	</div>