function myFunction() {


  
 var name=  $("#reg_no").val();

 if (name=='') { 

  alert("Please Fill Details");
 }

 else{

  $.ajax({
  type: "POST",
  url: "pass-data.php",
   
  data: {
   name:name,
  },
  success: function (data) {
   
  $("#form2").show();
 $('#form2').css("padding","10");
$('#form2').html(data);

 }
});



 }

  }

<!--Dispatched Updated beneficiary-->

function myFunctionNew() {


  
 var name=  $("#pass_dataNew").val();

 if (name=='') { 

  alert("Please Fill Details");
 }

 else{

  $.ajax({
  type: "POST",
  url: "pass_data_dispatched.php",
   
  data: {
   name:name,
  },
  success: function (data) {
   
  $("#form5").show();
 $('#form5').css("padding","10");
$('#form5').html(data);

 }
});



 }

  }




<!--invoice search by rgistration number-->

function myFunctionInvoice() {


  
 var name=  $("#pass_data_invoice").val();

 if (name=='') { 

  alert("Please Fill Details");
 }

 else{

  $.ajax({
  type: "POST",
  url: "pass_data_invoice.php",
   
  data: {
   name:name,
  },
  success: function (data) {
   
  $("#form3").show();
 $('#form3').css("padding","10");
$('#form3').html(data);

 }
});



 }

  }



















