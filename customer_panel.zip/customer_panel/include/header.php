<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
					<i class="icon-reorder shaded"></i>
				</a>

			  	<a class="brand" href="#">
			  		CMS | Admin
			  	</a>
			  	<div class="nav-collapse collapse navbar-inverse-collapse">
					<ul class="nav pull-left">
						
						
						<li class="nav-user dropdown">
							<a href="#"  data-toggle="dropdown">
								Manage users<b class="caret"></b>
							</a>
							<ul class="dropdown-menu">
								<li><a href="adduser.php">Add User</a></li>
								<li><a href="category.php">Add Category</a></li>
								<li><a href="addbeneficiary.php">Add Benificiary</a></li>
								<li><a href="search_benificiary.php">Search Benificiary By Reg Number</a></li>
								<!-- <li><a href="subcategory.php">Add Sub-Category</a></li>
								<li><a href="state.php">Add State</a></li> -->
								<li><a href="creda_beneficiary.php">Creda BeniFiciary</a></li>
								<li><a href="report_management.php">Report Management</a></li>
								<li><a href="addengineer.php">Add Engineer</a></li>
							</ul>
						</li>
					<li><a href="user-logs.php">
							User Login Log
						</a></li>

					
						
					</ul>
				</div>

				<div class="nav-collapse collapse navbar-inverse-collapse">
					<ul class="nav pull-right">
						<li><a href="#">
							Admin
						</a></li>
						<li class="nav-user dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<img src="images/user.png" class="nav-avatar" />
								<b class="caret"></b>
							</a>
							<ul class="dropdown-menu">
								<li><a href="change-password.php">Change Password</a></li>
								<li class="divider"></li>
								<li><a href="logout.php">Logout</a></li>
							</ul>
						</li>
					</ul>
				</div><!-- /.nav-collapse -->
			</div>
		</div><!-- /navbar-inner -->
	</div><!-- /navbar -->
