<?php
include('include/config.php');

if ( !defined( 'SQLSRV_FETCH_ASSOC' ) )
  define( 'SQLSRV_FETCH_ASSOC', 2 );
if( isset( $_POST['name'] ) )
{

$name = $_POST['name'];
$selectdata1 = " SELECT *  FROM [cmsDB].[dbo].[invoice_tbl] WHERE [reg_no] = '$name'  ";
	$params=array();
	$options=array("Scrollable" => SQLSRV_CURSOR_KEYSET);
	$query22=sqlsrv_query($con,$selectdata1,$params,$options);
	$rowcheck1=sqlsrv_fetch_array($query22);
	
	
}


 
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<div class="row">
								<h4>Invoice Details</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Invoice No</label>
                                        <input type="text" class="form-control" placeholder="Invoice Number" id="invoice_no"  name="invoice_no" value="<?php echo $rowcheck1['invoice_no'] ?>" readonly>
                                    </div>
									
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Invoice Date</label>
                                        <input type="text" class="form-control" placeholder="Invoice Date" id="invoice_date" name="invoice_date" value="<?php echo $rowcheck1['invoice_date']->format('Y-m-d'); ?>"  autofocus>
                                    </div>
                                </div>
	<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Registration Number</label>
                                        <input type="text" class="form-control" placeholder="Registeration Number" value="<?php echo $rowcheck1['reg_no'] ?>"  name="reg_no">
                                    </div>
                                </div>
								
                                
                            </div>
                            <div class="row">
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Buyer Order No</label>
                                        <input type="text" class="form-control" placeholder="Buyer Order No"  value="<?php echo $rowcheck1['buyer_order_no'] ?>"  name="buyer_order_no">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Buyer Date</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck1['buyer_date']->format('Y-m-d'); ?>"  name="buyer_date" id="buyer_date"  placeholder="Buyer Date"  autofocus>
                                    </div>
								
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Beneficiary Name</label>
                                        <input type="text" class="form-control"  value="<?php echo $rowcheck1['beneficiary_name'] ?>" placeholder="Beneficiary Name" name="beneficiary_name" id="beneficiary_name"   autofocus>
                                    </div>
								
                                </div>
								<div class="col-lg-4">
                                     <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">village</label>
                                        <input type="text" class="form-control" placeholder="village" value="<?php echo $rowcheck1['village'] ?>" name="village"  autofocus>
                                    </div>
                                </div>
                                </div>
                            </div>
                            
                            
						
							
							
							
							
	///////////////////////////////////////////////////////////
	<div class="row">
								
	
							 <div class="form-actions">
                                <button type="submit" name="updateinvoice"  class="btn btn-primary width-150">Update</button>
                                <button type="button" class="btn btn-default">Cancel</button>
                            </div>
	</div>
		<script src="include/js/main.js" type="text/javascript"></script>
<script>
	
	$(document).ready(function(){  
   $.datepicker.setDefaults({  
        dateFormat: 'yy-mm-dd'   
   });  
   $(function(){  
      $("#buyer_date").datepicker();
	     $("#invoice_date").datepicker();
	 
	    
   });    
  }); 
	</script>
	
	</body>
</html>