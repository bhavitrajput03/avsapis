<?php
session_start();
include('include/config.php');
date_default_timezone_set("Asia/Kolkata");

if(strlen($_SESSION['alogin'])==0)
	{	
header('location:../pages-login.php');
}	
if ( !defined( 'SQLSRV_FETCH_ASSOC' ) )
  define( 'SQLSRV_FETCH_ASSOC', 3 );


$username=$_SESSION['alogin'];
$userid=$_SESSION['id'];

function getZipcode($lat, $lon){
    if(!empty($lat)){
     
       
      $geocodeFromLatlon = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?latlng='.$lat.','.$lon.'&key=AIzaSyDWdzxfTXkZfSJ354e1QZ7ZFPwhr7srRD0');
        $output2 = json_decode($geocodeFromLatlon);
        if(!empty($output2)){
            $addressComponents = $output2->results[0]->address_components;
            foreach($addressComponents as $addrComp){
                if($addrComp->types[0] == 'postal_code'){
                    //Return the zipcode
                    return $addrComp->long_name;
                }
            }
            return false;
        }else{
            return false;
        }
    }else{
        return false;   
    }
}

function getfulladdresscode($lat, $lon){
    if(!empty($lat)){
      
       
      $geocodeFromLatlon1 = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?latlng='.$lat.','.$lon.'&key=AIzaSyDWdzxfTXkZfSJ354e1QZ7ZFPwhr7srRD0');
        $output3 = json_decode($geocodeFromLatlon1);
        if(!empty($output3)){
           return $addressComponents = $output3->results[0]->formatted_address;
          
        }else{
            return false;
        }
    }else{
        return false;   
    }
}


if( isset( $_GET['cid'] ) )
{

$name = $_GET['cid'];
	
	
$selectdata = " SELECT convert(varchar(10),instalation_date,121) as inst_date , * FROM [cmsDBNew].[dbo].[eesl_streetlight] WHERE [our_number] = '$name'  ";
	$params=array();
	$options=array("Scrollable" => SQLSRV_CURSOR_KEYSET);
	$query21=sqlsrv_query($con,$selectdata,$params,$options);
	$rowcheck=sqlsrv_fetch_array($query21,SQLSRV_FETCH_ASSOC);
	
	$lat1=$rowcheck['lat'];
	$lon1=$rowcheck['lng'];
	
	$gps_address =$rowcheck['gps_address'];
	
	 if(($lat1== '' || $lat1 == 'null' || $lat1 == 'NULL' || $lat1 == '0.0') && ($gps_address != 'NULL' || $gps_address != 'NOT FOUND' || $gps_address != '' )  )
	 {
	 $gpsaddress = "NOT FOUND";
		 $gpspincode = "NOT";
		 		 
	 }
	else {
	$gpspincode = getZipcode($lat1,$lon1);
    $gpsaddress = getfulladdresscode($lat1,$lon1);
		
	}
	
		
}

if(isset($_POST['update']))
{
	$uid_no=$_POST['uid_no'];
	$bname=$_POST['bname'];
	$reg_no=$_POST['reg_no'];
	$bfname=$_POST['bfname'];
	$contactno=$_POST['contactno'];
	
    $block=$_POST['block'];
	$village=$_POST['village'];
	$address=$_POST['address'];
	$gram_panchayat=$_POST['gram_panchayat'];
	
    $pincode = $_POST['pincode'];
	$status = $_POST['status'];
	$check1 = $_POST['check1'];
	$check2 = $_POST['check2'];
	$check3 = $_POST['check3'];
	//$empty = '';
	
	if(!empty($check1) and !empty($check2) and !empty($check3))
		
	{
		$update  = " set adhar_photo = 'null' , product_image_with_panel = 'null' , contact  = '0' , remarks_update ='WRONG UPLOAD' " ;
	}
	
	else if(!empty($check1) and !empty($check2) and empty($check3))
		{
		$update  =  " set adhar_photo = 'null' , product_image_with_panel = 'null' , remarks_update ='WRONG UPLOAD' " ;
	}
	
	  else if(!empty($check1) and empty($check2) and !empty($check3))
		{
		$update  =  " set adhar_photo = 'null' ,  contact  = '0' , remarks_update ='WRONG UPLOAD' " ;
	   }
	  else if(empty($check1) and !empty($check2) and !empty($check3))
		{
		$update  = " set product_image_with_panel = 'null' ,  contact  = '0' , remarks_update ='WRONG UPLOAD' ";
	   }
	
		else if(empty($check1) and empty($check2) and !empty($check3))
		{
		$update  =  " set contact  = '0' , remarks_update ='WRONG UPLOAD' " ;
	    }
	   else if(empty($check1) and !empty($check2) and empty($check3))
		 {
		 $update  =  " set product_image_with_panel = 'null' , remarks_update ='WRONG UPLOAD' ";
	     }
	    else if(!empty($check1) and empty($check2) and empty($check3))
		 {
		 $update  =  " set adhar_photo = 'null' , remarks_update ='WRONG UPLOAD' ";
	    }
	
	
	    $inst_date=$_POST['inst_date'];

	     $date1=date('Y-m-d H:i:s');
	
	
	if($status == 'WRONG UPLOAD' and $check1 == '' and $check2 == '' and $check3 ==  '' )
	{
	echo "<script language='javascript' type='text/javascript'>";
echo "alert('Please Select Some Field');";
echo "window.location.href='beneficiery_update_new.php?cid=$name' ";
echo "</script>";

	
	
	}
	
	
	else if($status != 'WRONG UPLOAD')
	{
		
	$query=sqlsrv_query($con, "update [cmsDBNew].[dbo].[eesl_streetlight] set beneficiary_name='$bname',beneficiary_fname='$bfname', block='$block',contact='$contactno',gram_panchayat='$gram_panchayat',village='$village',address='$address',pincode = '$pincode' , instalation_date = '$inst_date' , uid_no = '$uid_no' , gps_address= '$gpsaddress' , gps_pincode = '$gpspincode' , remarks_update ='$status' ,
	remarks_date = '$date1' , remarks_update_by_id = '$userid' , remarks_through = 'WEB PANEL' 
	where our_number ='$reg_no'  ");
		

	
if($query){

echo "<script language='javascript' type='text/javascript'>";
echo "alert('Beneficiary Details Successfully Updated');";
echo "window.location.href='beneficiery_update_new.php?cid=$name' ";
echo "</script>";

}
	
}
	
else {
	
$query_update =  sqlsrv_query($con,"update [cmsDBNew].[dbo].[eesl_streetlight] $update , remarks_date = '$date1' , remarks_update_by_id = '$userid' , remarks_through = 'WEB PANEL'   where our_number ='$reg_no' ");
		
if($query_update){

echo "<script language='javascript' type='text/javascript'>";
echo "alert(' Successfully Updated');";
echo "window.location.href='beneficiery_update_new.php?cid=$name' ";
echo "</script>";

}

}
	

	
}

?>


<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Gautam Solar | </title>

    <link href="../assets/common/img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
    <link href="../assets/common/img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
    <link href="../assets/common/img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
    <link href="../assets/common/img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
    <link href="../assets/common/img/favicon.png" rel="icon" type="image/png">
    <link href="favicon.ico" rel="shortcut icon">

    <!-- HTML5 shim and Respond.js for < IE9 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Vendors Styles -->
    <!-- v1.0.0 -->
    <link rel="stylesheet" type="text/css" href="../assets/vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/jscrollpane/style/jquery.jscrollpane.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/ladda/dist/ladda-themeless.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/select2/dist/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/fullcalendar/dist/fullcalendar.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/cleanhtmlaudioplayer/src/player.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/cleanhtmlvideoplayer/src/player.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/bootstrap-sweetalert/dist/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/summernote/dist/summernote.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/owl.carousel/dist/assets/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/ionrangeslider/css/ion.rangeSlider.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/datatables/media/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/c3/c3.min.css">
    

    <!-- Clean UI Styles -->
    <link rel="stylesheet" type="text/css" href="../assets/common/css/source/main.css">

    <!-- Vendors Scripts -->
    <!-- v1.0.0 -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
	
  
	 <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="../assets/vendors/tether/dist/js/tether.min.js"></script>
    <script src="../assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../assets/vendors/jquery-mousewheel/jquery.mousewheel.min.js"></script>
    <script src="../assets/vendors/jscrollpane/script/jquery.jscrollpane.min.js"></script>
    <script src="../assets/vendors/spin.js/spin.js"></script>
    <script src="../assets/vendors/ladda/dist/ladda.min.js"></script>
    <!--<script src="../assets/vendors/select2/dist/js/select2.full.min.js"></script>-->
    <!--<script src="../assets/vendors/html5-form-validation/dist/jquery.validation.min.js"></script>-->
    <script src="../assets/vendors/jquery-typeahead/dist/jquery.typeahead.min.js"></script>
    <script src="../assets/vendors/jquery-mask-plugin/dist/jquery.mask.min.js"></script>
    <script src="../assets/vendors/autosize/dist/autosize.min.js"></script>
    <!--<script src="../assets/vendors/bootstrap-show-password/bootstrap-show-password.min.js"></script>-->
    <script src="../assets/vendors/moment/min/moment.min.js"></script>
    <script src="../assets/vendors/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
  
   
    <script src="../assets/vendors/bootstrap-sweetalert/dist/sweetalert.min.js"></script>
    <script src="../assets/vendors/remarkable-bootstrap-notify/dist/bootstrap-notify.min.js"></script>
    <script src="../assets/vendors/summernote/dist/summernote.min.js"></script>
    <script src="../assets/vendors/owl.carousel/dist/owl.carousel.min.js"></script>
    <script src="../assets/vendors/ionrangeslider/js/ion.rangeSlider.min.js"></script>
    <script src="../assets/vendors/nestable/jquery.nestable.js"></script>
    <script src="../assets/vendors/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../assets/vendors/datatables/media/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/vendors/datatables-fixedcolumns/js/dataTables.fixedColumns.js"></script>
    <script src="../assets/vendors/datatables-responsive/js/dataTables.responsive.js"></script>
    <script src="../assets/vendors/editable-table/mindmup-editabletable.js"></script>
    <script src="../assets/vendors/d3/d3.min.js"></script>
    <script src="../assets/vendors/c3/c3.min.js"></script>
    
  
    <!-- v1.0.1 -->
    
    <!-- v1.1.1 -->
    <script src="../assets/vendors/gsap/src/minified/TweenMax.min.js"></script>
    <script src="../assets/vendors/hackertyper/hackertyper.js"></script>
    <script src="../assets/vendors/jquery-countTo/jquery.countTo.js"></script>

    <!-- Clean UI Scripts -->
    <script src="../assets/common/js/common.js"></script>
    <script src="../assets/common/js/demo.temp.js"></script>
	<script>
		
	
		

	function valid()
{
	if(document.reg_benificiary.bname.value=="")
{
alert("Benificiary Name Filed is Empty !!");
document.reg_benificiary.bname.focus();
return false;
}
	

else if(document.reg_benificiary.bfname.value=="")
{
alert("Registration No Filed is Empty !!");
document.reg_benificiary.bfname.focus();
return false;
}
	
return true;	
}
		
		
		window.onload = function() {
			if(document.getElementById('yesCheck').checked) {
    document.getElementById('ifYes').style.display = 'block';
    
			}
			else if(document.getElementById('noCheck').checked) {
        document.getElementById('ifNo').style.display = 'block';
       
     
   }
}
function yesnoCheck() {
    if (document.getElementById('yesCheck').checked) {
        document.getElementById('ifYes').style.display = 'block';
        document.getElementById('ifNo').style.display = 'none';
     
    } 
    else if(document.getElementById('noCheck').checked) {
        document.getElementById('ifNo').style.display = 'block';
        document.getElementById('ifYes').style.display = 'none';
     
   }
}
	
		
	
	</script>
</head>
<body class="theme-default">
<!--Header file HERE-->
	<?php include('header.php'); ?>
	<!-- END OF  HEADER FILE HERE-->

<section class="page-content">
<div class="page-content-inner">

    <!-- Dashboard -->
    <div class="dashboard-container">
       
      
     
        <div class="row">
           	
			<div class="col-lg-12 col-sm-12 col-md-12">
                    <div class="margin-bottom-50">
                      
						
                        <br />
                        <!-- Vertical Form -->
                        <form class="form-login" method="post" name="reg_benificiary" enctype="multipart/form-data" id="form2" onSubmit="return valid();">
							
							<h4 style="text-align:center">PERSONAL DETAILS</h4>
							<div class="row" >
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Our Number</label>
                                        <input type="text" class="form-control" placeholder="Registration Number" id="reg_no"  name="reg_no" value="<?php echo $rowcheck['our_number'] ?>" readonly>
                                    </div>
								 </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Beneficiary Name</label>
  <input type="text" class="form-control" placeholder="Full Name" name="bname" value="<?php echo $rowcheck['beneficiary_name'] ?>"  autofocus>
                                    </div>
                                </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Father/Husband Name</label>
                                        <input type="text" class="form-control" placeholder="Father Name" value="<?php echo $rowcheck['beneficiary_fname'] ?>"  name="bfname">
                                    </div>
                                </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Contact Number</label>
                                        <input type="text" class="form-control"  value="<?php echo $rowcheck['contact'] ?>" maxlength="10" name="contactno" id="contact_no"  placeholder="Contact no"  autofocus>
                                    </div>
										<span id="contact-availability-status" style="font-size:12px;"></span>
								</div>
                                
                            </div>
                         
                            <div class="row" >
								
								 <div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30"> State</label>
                                        <input type="text" class="form-control"   value="<?php echo $rowcheck['state_name'] ?>" placeholder="State Name"   autofocus>
                                    </div>
                                </div>
								 <div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30"> District</label>
                                        <input type="text" class="form-control"   value="<?php echo $rowcheck['dist_name']; ?>" placeholder="District"    autofocus>
                                    </div>
                                </div>
								 <div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Constituency</label>
                                        <input type="text" class="form-control"  value="<?php echo $rowcheck['constituency'] ?>" placeholder="Constituency"  autofocus>
                                    </div>
                                </div>
								 <div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Zone</label>
                                        <input type="text" class="form-control"  value="<?php echo $rowcheck['zone_name'] ?>" placeholder="Zone Name"   autofocus>
                                    </div>
                                </div>
								
							</div>
                                  <div class="row" >
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Village</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['village'] ?>" name="village" placeholder="village"  autofocus>
                                    </div>
                                </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Block</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['block'] ?>" name="block" placeholder="block"  autofocus>
                                    </div>
                                </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">Pincode</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['pincode'] ?>" name="pincode" placeholder="pincode"  autofocus>
                                    </div>
                                </div>
									  	<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30" >Gram Panchayat</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['gram_panchayat'] ?>"   name="gram_panchayat"   placeholder="Gram Panchayat"  autofocus>
                                    </div>
									
                                </div>
                            </div>
                           
						<div class ="row">
							 <div class="col-lg-4 col-sm-4 col-md-4">
                                    <div class="form-group">
                                        <label for="l30">Address</label>
                                        <input type="text" class="form-control" placeholder="Address" value="<?php echo $rowcheck['address'] ?>" name="address"  autofocus>
                                    </div>
                                </div>
								<div class="col-lg-4 col-sm-4 col-md-4">
                                    <div class="form-group">
                                        <label for="l30">UID No</label>
                                        <input type="text" class="form-control" placeholder="UID No" value="<?php echo $rowcheck['uid_no'] ?>" name="uid_no"  autofocus>
                                    </div>
                                </div>
								</div>
							<br/>
							<h4 style="text-align:center">SITE UPDATE STATUS</h4>
								<div class ="row">
									<div class="col-lg-4 col-sm-4 col-md-4">
                                    <div class="form-group">
                                        <label for="l30">SITE UPDATE STATUS</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['site_update_status'] ?>"   autofocus>
                                    </div>
                                </div>
									
							    </div>
							<h4 style="text-align:center">UPDATED DATA</h4>
								<div class ="row">
										<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">UPDATE Name</label>
  <input type="text" class="form-control" placeholder="Full Name"  value="<?php echo $rowcheck['update_beneficiary_name'] ?>"  autofocus>
                                    </div>
                                </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">UPDATE Father/Husband Name</label>
                                        <input type="text" class="form-control" placeholder="Father Name" value="<?php echo $rowcheck['update_beneficiary_fname'] ?>" >
                                    </div>
                                </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">UPDATE Contact Number</label>
                                        <input type="text" class="form-control"  value="<?php echo $rowcheck['update_beneficiary_mob'] ?>"  placeholder="Contact no"  autofocus>
                                    </div>
										
								</div>
									
									
							    </div>
							<div class ="row">
										<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">UPDATE Adress</label>
  <input type="text" class="form-control" placeholder="Update Address"  value="<?php echo $rowcheck['update_address'] ?>"  autofocus>
                                    </div>
                                </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">UPDATE Block</label>
                                        <input type="text" class="form-control" placeholder="Update Block" value="<?php echo $rowcheck['update_benificiary_block'] ?>" >
                                    </div>
                                </div>
								<div class="col-lg-3 col-sm-3 col-md-3">
                                    <div class="form-group">
                                        <label for="l30">UPDATE Village</label>
                                        <input type="text" class="form-control"  value="<?php echo $rowcheck['update_benificiary_village'] ?>"  placeholder="Update Village"  autofocus>
                                    </div>
										
								</div>
									
									
							    </div>
							
                               <div class="row">
								
                              
                                <div class="col-lg-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <label for="l30">Adhar Image</label><br>
                                    <img src="<?php echo $rowcheck['adhar_photo']; ?>"  width="300" height="300"/>
                                    </div>
								
									<div><a target="_BLANK" href="<?php echo htmlentities($rowcheck['adhar_photo']);?>">Download</a></div>
                                </div>
								 <div class="col-lg-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <label for="l30">Product Photo</label><br>
                                    <img src="<?php echo $rowcheck['product_image_with_panel']; ?>"  width="300" height="300"/>
                                    </div>
								
									 <div><a target="_BLANK" href="<?php echo htmlentities($rowcheck['product_image_with_panel']);?>">Download</a></div>
                                </div>
                            </div>
								 
								<div class="row">
								 <div class="col-lg-8 col-sm-8">
									 <div class="form-group">
											<label for="l30">STATUS </label><br>
											<input type="radio" onclick="javascript:yesnoCheck();" id="noCheck"   value="COMPLETED" name="status" <?php if($rowcheck['status']=='COMPLETED')  echo 'checked="checked"';?> />COMPLETED &nbsp;&nbsp;&nbsp;

										 <input type="radio" onclick="javascript:yesnoCheck();" id="yesCheck"  value="WRONG UPLOAD" name="status" <?php if($rowcheck['status']=='WRONG UPLOAD')  echo 'checked="checked"';?> />WRONG UPLOAD



									  </div>
                                 </div>
							   </div>
								 
							<div class="row" id="ifYes" style="display:none">
									 
								<div class="checkbox">
                           <label><input type="checkbox" name = "check1" value="1">ADHAR IMAGE</label>
                                </div>
                                <div class="checkbox">
                           <label><input type="checkbox" name = "check2" value="2">PRODUCT IMAGE</label>
                                 </div>
                                <div class="checkbox ">
                           <label><input type="checkbox" name = "check3" value="3">CONTACT</label>
                                </div>
									 
						   </div>
								 
						
                            <div class="form-actions">
                                <button type="submit" name="update"  class="btn btn-primary width-150">Update</button>
								
                              
                            </div>
                            
                        </form>
                        <!-- End Vertical Form -->
                    </div>
			
			
            
        </div>
   
    </div>
    <div class="row">
        <div class="col-xl-12">
            
    </div>
    <!-- End Dashboard -->

</div>
	</div>
	</div>

<!--AIzaSyC4xiLr53xS-X32CJUfihNuiAa4rr7NGqg  -->
<!-- Page Scripts -->
	 <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDWdzxfTXkZfSJ354e1QZ7ZFPwhr7srRD0&callback=initMap">
    </script>
		<!--<script src="include/js/main.js" type="text/javascript"></script> -->
<script>
	
	$(document).ready(function(){  
   $.datepicker.setDefaults({  
	   changeMonth: true,
        changeYear: true,
	   yearRange: '2000:2019',
        dateFormat: 'yy-mm-dd'   
   });  
   $(function(){  
     $("#inst_date").datepicker();
	     $("#invoice_date").datepicker();
	   $("#com_date").datepicker();
	    
   });    
  }); 
	
	
    $(function() {

        ///////////////////////////////////////////////////////////
        // COUNTERS
        $('.counter-init').countTo({
            speed: 1500
        });

        ///////////////////////////////////////////////////////////
        // ADJUSTABLE TEXTAREA
        autosize($('#textarea'));

        ///////////////////////////////////////////////////////////
        // CUSTOM SCROLL
        if (!cleanUI.hasTouch) {
            $('.custom-scroll').each(function() {
                $(this).jScrollPane({
                    autoReinitialise: true,
                    autoReinitialiseDelay: 100
                });
                var api = $(this).data('jsp'),
                        throttleTimeout;
                $(window).bind('resize', function() {
                    if (!throttleTimeout) {
                        throttleTimeout = setTimeout(function() {
                            api.reinitialise();
                            throttleTimeout = null;
                        }, 50);
                    }
                });
            });
        }

        ///////////////////////////////////////////////////////////
        // CALENDAR
        

        ///////////////////////////////////////////////////////////
        // CAROUSEL WIDGET
        $('.carousel-widget').carousel({
            interval: 4000
        });

        $('.carousel-widget-2').carousel({
            interval: 6000
        });

        ///////////////////////////////////////////////////////////
        // DATATABLES
        $('#example1').DataTable({
            responsive: true,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
        });

       

       


    });
</script>
<!-- End Page Scripts -->
</section>

<div class="main-backdrop"><!-- --></div>

</body>
</html>