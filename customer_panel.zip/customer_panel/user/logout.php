<?php
session_start();
$_SESSION['alogin']=="";
session_unset();
//session_destroy();
$_SESSION['errmsg']="You have Successfully logout";
?>
<script language="javascript">
document.location="../pages-login.php";
</script>
