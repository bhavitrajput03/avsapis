<?php
$username=$_SESSION['alogin'];
?>

<nav class="left-menu" left-menu>
    <div class="logo-container">
        <a href="index.php" class="logo">
            <!--<img src="../assets/common/img/logo.png" alt="Clean UI Admin Template" />
            <img class="logo-inverse" src="../assets/common/img/logo-inverse.png" alt="Clean UI Admin Template" />-->
        </a>
    </div>
    <div class="left-menu-inner scroll-pane">
        <ul class="left-menu-list left-menu-list-root list-unstyled">
           
            <li class="left-menu-list-active">
                <a class="left-menu-link" href="index.php">
                    <i class="left-menu-link-icon icmn-home2"><!-- --></i>
                    <span class="menu-top-hidden">Home</span>
                </a>
            </li>
			
				<!--<li class="left-menu-list">
                <a class="left-menu-link" href="test.php">
                    <i class="left-menu-link-icon icmn-home2"></i>
                    <span class="menu-top-hidden">TESTING</span>
                </a>
            </li> -->
            
           <li class="left-menu-list-separator"></li>
            <li class="left-menu-list-submenu">
                <a class="left-menu-link" href="javascript: void(0);">
                    <i class="left-menu-link-icon icmn-files-empty2"></i>
                    Engineer
                </a>
                <ul class="left-menu-list list-unstyled">
                   
                   <!-- <li>
                        <a  class="left-menu-link" href="register_saubhagya_beneficiary.php">
                            Register Beneficiary
                        </a>
                    </li> -->
					
					 
					
				
					<li>
                        <a  class="left-menu-link" href="engineerlist.php">
                            Engineer List
                        </a>
                    </li>
					
                   
                   
                </ul>
            </li>
			<li class="left-menu-list-separator"></li> 
           
			
			
		<!--	 <li class="left-menu-list-separator"></li>
			<li class="left-menu-list-submenu">
                <a class="left-menu-link" href="javascript: void(0);">
                    <i class="left-menu-link-icon icmn-files-empty2"></i>
                   Download Section
                </a>
                <ul class="left-menu-list list-unstyled">
                    
               
					<li>
                        <a  class="left-menu-link" href="downloadallExcel.php">
                            Download Excel
                        </a>
                    </li>
				
                   
                   
                </ul>
            </li> -->
			
			
			<!-- <li class="left-menu-list-separator"></li>
			<li class="left-menu-list-submenu">
                <a class="left-menu-link" href="javascript: void(0);">
                    <i class="left-menu-link-icon icmn-files-empty2"></i>
                    Report
                </a>
                <ul class="left-menu-list list-unstyled">
                    <li>
                        <a  class="left-menu-link" href="installationreport.php">
                            Daily Updated Report
                        </a>
                    </li>
					<li>
                        <a  class="left-menu-link" href="daily_register_report.php">
                            Daily Register Report
                        </a>
                    </li>
					<li>
                        <a  class="left-menu-link" href="completed_report.php">
                            Completed Project
                        </a>
                    </li>
                 
					
                   
                   
                </ul>
            </li> -->
            <li class="left-menu-list-separator"><!-- --></li>
			<!--<li class="left-menu-list-submenu">
                <a class="left-menu-link" href="javascript: void(0);">
                    <i class="left-menu-link-icon icmn-files-empty2"></i>
                    Inventory
                </a>
                <ul class="left-menu-list list-unstyled">
					<li>
                        <a class="left-menu-link" target='_BLANK'  href="inventoryin.php">
                            Inventory ADD
                        </a>
                    </li>
                    
                    <li>
                        <a class="left-menu-link" target='_BLANK'  href="inventorylist.php">
                           Inventory List 
                        </a>
                    </li>
					
					
                   
                   
                </ul>
            </li>-->
            
           
          
        </ul>
    </div>
</nav>
<nav class="top-menu">
    <div class="menu-icon-container hidden-md-up">
        <div class="animate-menu-button left-menu-toggle">
            <div><!-- --></div>
        </div>
    </div>
    <div class="menu">
        <div class="menu-user-block">
            <div class="dropdown dropdown-avatar">
                <a href="javascript: void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <span class="avatar" href="javascript:void(0);">
                        <img src="../assets/common/img/temp/avatars/1.jpg" alt="Alternative text to the image">
                    </span>
                </a>
                <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="" role="menu">
                    <a class="dropdown-item" href="javascript:void(0)"><i class="dropdown-icon icmn-user"></i> <?php echo $username; ?></a>
                    <div class="dropdown-divider"></div>
                    <div class="dropdown-header">Home</div>
					 <a class="dropdown-item" href="change_password.php"><i class="dropdown-icon icmn-circle-right"></i> System Dashboard</a>
                    <a class="dropdown-item" href="javascript:void(0)"><i class="dropdown-icon icmn-circle-right"></i> System Dashboard</a>
                    <a class="dropdown-item" href="javascript:void(0)"><i class="dropdown-icon icmn-circle-right"></i> User Boards</a>
                    <a class="dropdown-item" href="javascript:void(0)"><i class="dropdown-icon icmn-circle-right"></i> Issue Navigator (35 New)</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="logout.php"><i class="dropdown-icon icmn-exit"></i> Logout</a>
                </ul>
            </div>
        </div>
        <div class="menu-info-block">
            <div class="left">
                <div class="header-buttons">
                    
                    <div class="dropdown">
                        <a href="javascript: void(0);" class="dropdown-toggle dropdown-inline-button" data-toggle="dropdown" aria-expanded="false">
                            <i class="dropdown-inline-button-icon icmn-database"></i>
                            <span class="hidden-lg-down">Dashboards</span>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="" role="menu">
                            <div class="dropdown-header">Active</div>
                            <a class="dropdown-item" href="javascript:void(0)">Project Management</a>
                            
                        </ul>
                    </div>
                   
                </div>
            </div>
            <div class="left hidden-md-down">
                
            </div>
            <div class="right hidden-md-down margin-left-20">
                
            </div>
            
        </div>
    </div>
</nav>