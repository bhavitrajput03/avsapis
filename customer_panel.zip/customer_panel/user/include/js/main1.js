function contact_noAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "add_beneficiary_valadation/contact_no_availability.php",
data:'contact='+$("#contact_no").val(),
type: "POST",
success:function(data){
$("#user-availability-status2").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}


function sanctionAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "sanction_no_availability.php",
data:'sanctionnumber='+$("#sanctionnumber").val(),
type: "POST",
success:function(data){
$("#sanction-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}


function alternate_noAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "add_beneficiary_valadation/check_alternate_availability.php",
data:'alternate='+$("#alcontact").val(),
type: "POST",
success:function(data){
$("#user-availability-status3").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}


function adhar_noAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "add_beneficiary_valadation/adhar_no_availability.php",
data:'adhar_no='+$("#adhar_no").val(),
type: "POST",
success:function(data){
$("#user-availability-status4").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}



function uid_noAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "add_beneficiary_valadation/uid_no_availability.php",
data:'uid_no='+$("#uid_no").val(),
type: "POST",
success:function(data){
$("#user-availability-status5").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
