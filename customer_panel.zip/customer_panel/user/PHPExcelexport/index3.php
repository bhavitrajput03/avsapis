<?php
require_once 'Classes/PHPExcel.php';

$dsfsdf="Krishna Pal Yadav";

//create PHPExcel object
$excel = new PHPExcel();
$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle('Example');

$styleBorder = array(
  'borders' => array(
    'allborders' => array(
      'style' => PHPExcel_Style_Border::BORDER_THIN
  )
)
);
       
     
     
  

 $styleFontBold1 = array(
    'font'  => array(
        'bold'  => true,
        'size'  => 14,	
        //'name'  => 'Verdana'
    ));
 $styleFontBold2 = array(
    'font'  => array(
        'bold'  => true,
        'size'  => 12,	
        //'name'  => 'Verdana'
    ));
  $styleFontBold3 = array(
    'font'  => array(
        
        'size'  => 10,  
        //'name'  => 'Verdana'
    ));

//$excel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
 $excel->getActiveSheet()->mergeCells('A1:I1');

$excel->getActiveSheet()->setCellValue('A1','INSPECTION CUM COMMISSIONING REPORT');
//$excel->getActiveSheet()->getStyle('A1:L1')->applyFromArray($styleBorder);
$excel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($styleFontBold1);

$excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
 $excel->getActiveSheet()->mergeCells('A3:I3');
 $excel->getActiveSheet()->setCellValue('A3','Details of Material & Works for Solar Pumping System');
 	$excel->getActiveSheet()->getStyle('A3:I3')->applyFromArray($styleFontBold2);
 	$excel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal('center');
 	 $excel->getActiveSheet()->mergeCells('A4:I4');
 $excel->getActiveSheet()->setCellValue('A4','("Mukhya Mantri Solar Pump Yojna")');
 	$excel->getActiveSheet()->getStyle('A4:I4')->applyFromArray($styleFontBold2);
 	$excel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal('center');

 	/*start here */
$excel->getActiveSheet()->mergeCells('A6:I6');
$excel->getActiveSheet()->getStyle('A6:I6')->applyFromArray($styleBorder);
 	$excel->getActiveSheet()->setCellValue('A6','Report No:DREO-ASKN/CMSPS-SAC/IR.NO 11/2018 &nbsp;&nbsp;&nbsp; Date:2018-04-19');

 	$excel->getActiveSheet()->setCellValue('A8','Name of Farmer:'.$dsfsdf);
     //   $excel->getActiveSheet()->setCellValue('B8',$dsfsdf);


 	
 	$excel->getActiveSheet()->mergeCells('A8:D10');
 	$excel->getActiveSheet()->getStyle('A8')->getAlignment()->setVertical('top');
 	
 	$excel->getActiveSheet()->getStyle('A8')->getAlignment()->setWrapText(true);
    $excel->getActiveSheet()->getStyle('A8:D10')->applyFromArray($styleBorder);
    $excel->getActiveSheet()->mergeCells('A11:D11');
    $excel->getActiveSheet()->setCellValue('A11','Mob. No.');
    $excel->getActiveSheet()->getStyle('A11:D11')->applyFromArray($styleBorder);

    $excel->getActiveSheet()->mergeCells('A12:D12');
    $excel->getActiveSheet()->setCellValue('A12','Category of Farmer.');
        $excel->getActiveSheet()->getStyle('A12:D12')->applyFromArray($styleBorder);


    $excel->getActiveSheet()->mergeCells('A13:D13');
    $excel->getActiveSheet()->setCellValue('A13','SPV Modules/Array');
        $excel->getActiveSheet()->getStyle('A13:D13')->applyFromArray($styleBorder);

    $excel->getActiveSheet()->mergeCells('A14:D14');
    $excel->getActiveSheet()->setCellValue('A14','Total Solar Panel:...16...x...300..Wp');
        $excel->getActiveSheet()->getStyle('A14:D14')->applyFromArray($styleBorder);

    $excel->getActiveSheet()->mergeCells('A15:D15');
    $excel->getActiveSheet()->setCellValue('A15','Panel Manufacture: Gautam Solar Pvt.Ltd');
        $excel->getActiveSheet()->getStyle('A15:D15')->applyFromArray($styleBorder);

    $excel->getActiveSheet()->mergeCells('A16:D16');
    $excel->getActiveSheet()->setCellValue('A16','Wp of Each Modules:300 Watt');
        $excel->getActiveSheet()->getStyle('A16:D16')->applyFromArray($styleBorder);


        $excel->getActiveSheet()->setCellValue('A17','S.No.');
         $excel->getActiveSheet()->setCellValue('A18','1');
          $excel->getActiveSheet()->setCellValue('A19','2');
           $excel->getActiveSheet()->setCellValue('A20','3');
              $excel->getActiveSheet()->setCellValue('A21','4');
          $excel->getActiveSheet()->setCellValue('A22','5');
           $excel->getActiveSheet()->setCellValue('A23','6');
              $excel->getActiveSheet()->setCellValue('A24','7');
          $excel->getActiveSheet()->setCellValue('A25','8');
           $excel->getActiveSheet()->setCellValue('A26','9');
              $excel->getActiveSheet()->setCellValue('A27','10');
          $excel->getActiveSheet()->setCellValue('A28','11');
           $excel->getActiveSheet()->setCellValue('A29','12');
              $excel->getActiveSheet()->setCellValue('A30','13');
          $excel->getActiveSheet()->setCellValue('A31','14');
           $excel->getActiveSheet()->setCellValue('A32','15');
              $excel->getActiveSheet()->setCellValue('A33','16');
              $excel->getActiveSheet()->setCellValue('A34','17');
              $excel->getActiveSheet()->setCellValue('A35','18');
              $excel->getActiveSheet()->setCellValue('A36','19');
              $excel->getActiveSheet()->setCellValue('A37','20');
              $excel->getActiveSheet()->setCellValue('A38','21');
              $excel->getActiveSheet()->setCellValue('A39','22');
              $excel->getActiveSheet()->setCellValue('A40','23');
            
             

                  $excel->getActiveSheet()->mergeCells('B17:D17');
                   $excel->getActiveSheet()->setCellValue('B17','SSGSO23002591734567');
                $excel->getActiveSheet()->mergeCells('B18:D18');
                 $excel->getActiveSheet()->setCellValue('B18','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B19:D19');
                   $excel->getActiveSheet()->setCellValue('B19','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B20:D20');
                   $excel->getActiveSheet()->setCellValue('B20','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B21:D21');
                   $excel->getActiveSheet()->setCellValue('B21','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B22:D22');
                   $excel->getActiveSheet()->setCellValue('B22','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B23:D23');
                   $excel->getActiveSheet()->setCellValue('B23','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B24:D24');
                   $excel->getActiveSheet()->setCellValue('B24','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B25:D25');
                   $excel->getActiveSheet()->setCellValue('B25','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B26:D26');
                   $excel->getActiveSheet()->setCellValue('B26','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B27:D27');
                   $excel->getActiveSheet()->setCellValue('B27','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B28:D28');
                   $excel->getActiveSheet()->setCellValue('B28','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B29:D29');
                   $excel->getActiveSheet()->setCellValue('B29','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B30:D30');
                   $excel->getActiveSheet()->setCellValue('B30','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B31:D31');
                   $excel->getActiveSheet()->setCellValue('B31','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B32:D32');
                   $excel->getActiveSheet()->setCellValue('B32','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B33:D33');
                   $excel->getActiveSheet()->setCellValue('B33','SSGSO23002591734567');
                  $excel->getActiveSheet()->mergeCells('B34:D34');
                  $excel->getActiveSheet()->mergeCells('B35:D35');
                  $excel->getActiveSheet()->mergeCells('B36:D36');
                  $excel->getActiveSheet()->mergeCells('B37:D37');
                  $excel->getActiveSheet()->mergeCells('B38:D38');
                  $excel->getActiveSheet()->mergeCells('B39:D39');
                  $excel->getActiveSheet()->mergeCells('B40:D40');
                
                 

                  $excel->getActiveSheet()->getStyle('A17:D40')->applyFromArray($styleBorder);





                  /*nest para*/

                  $excel->getActiveSheet()->mergeCells('E8:G8');
                  $excel->getActiveSheet()->setCellValue('E8','Village:Bimoniya');
                  $excel->getActiveSheet()->mergeCells('H8:I8');
                  $excel->getActiveSheet()->setCellValue('H8','Block:Mungulia');
                  $excel->getActiveSheet()->mergeCells('E9:G9');
                  $excel->getActiveSheet()->setCellValue('E9','District:Ashok Nagar');
                  $excel->getActiveSheet()->mergeCells('H9:I9');
                  $excel->getActiveSheet()->setCellValue('H9','Pincode:3554566');
                  $excel->getActiveSheet()->mergeCells('E10:I10');
                  $excel->getActiveSheet()->setCellValue('E10','Invoice/bill No.& date:GS|BPL|0024 Dated -25-10-2017');
                  $excel->getActiveSheet()->mergeCells('E11:I11');
                  $excel->getActiveSheet()->setCellValue('E11','MPUVN Order No: MPUVN|SP-CM4|28|2017|1955 Bhopal');
                  $excel->getActiveSheet()->mergeCells('E12:I12');
                   $excel->getActiveSheet()->setCellValue('E12','Dated:21-08-2017');
                      $excel->getActiveSheet()->getStyle('E8:I12')->applyFromArray($styleBorder);
                      $excel->getActiveSheet()->mergeCells('E13:I13');
                       $excel->getActiveSheet()->setCellValue('E13','Motor and Pump Details');

                        $excel->getActiveSheet()->setCellValue('E14','Type');
                         $excel->getActiveSheet()->setCellValue('E15','AC/DC');
                          $excel->getActiveSheet()->setCellValue('E16','HP');
                           $excel->getActiveSheet()->setCellValue('E17','Haed 50m');
                            $excel->getActiveSheet()->setCellValue('E18','Make & Model:');
                           $excel->getActiveSheet()->getColumnDimension('E')->setWidth(17);

                             $excel->getActiveSheet()->setCellValue('E19','Sr.No. Motor & Pump');
                              $excel->getActiveSheet()->setCellValue('E20','Any Other Information');

                              $excel->getActiveSheet()->mergeCells('F14:I14');
                              $excel->getActiveSheet()->setCellValue('F14','Submersible Pump');
                               $excel->getActiveSheet()->mergeCells('F15:I15');
                               $excel->getActiveSheet()->setCellValue('F15','AC');
                                $excel->getActiveSheet()->mergeCells('F16:I16');
                                $excel->getActiveSheet()->setCellValue('F16','5 HP');
                                 $excel->getActiveSheet()->mergeCells('F17:I17');
                                 $excel->getActiveSheet()->setCellValue('F17','DSP6MFF09 Model No.');
                                  $excel->getActiveSheet()->mergeCells('F18:I18');
                                  $excel->getActiveSheet()->setCellValue('F18','Gautam Solar Pvt Ltd & SSGS-72P300');
                                   $excel->getActiveSheet()->mergeCells('F19:I19');
                                   $excel->getActiveSheet()->setCellValue('F19','P-1709919,M-1709927');
                                    $excel->getActiveSheet()->mergeCells('F20:I20');
                                    $excel->getActiveSheet()->setCellValue('E20','Any Other Information');

                                $excel->getActiveSheet()->getStyle('E14:I20')->applyFromArray($styleBorder);

                                $excel->getActiveSheet()->mergeCells('E21:I21');
                                $excel->getActiveSheet()->setCellValue('E21','Other Details');

                                 $excel->getActiveSheet()->mergeCells('E22:I22');
                                 $excel->getActiveSheet()->setCellValue('E22','Water Source: Tank/Pond/Well/Tubewell/Surface etc');

                                       $excel->getActiveSheet()->mergeCells('E23:F23');
                                        $excel->getActiveSheet()->setCellValue('E23','Controller');
                                     $excel->getActiveSheet()->mergeCells('G23:I23');
                                      $excel->getActiveSheet()->setCellValue('G23','No:SS007222');

                                    $excel->getActiveSheet()->mergeCells('E24:F24');
                                     $excel->getActiveSheet()->setCellValue('E24','Make');
                                    $excel->getActiveSheet()->mergeCells('G24:I24');
                                     $excel->getActiveSheet()->setCellValue('G24','Gautam Solar Pvt Ltd');

                                        $excel->getActiveSheet()->mergeCells('E25:F25');
                                         $excel->getActiveSheet()->setCellValue('E25','GI Structure(duly galvanized)');
                                    $excel->getActiveSheet()->mergeCells('G25:I25');
                                     $excel->getActiveSheet()->setCellValue('G25','Yes');
                                      $excel->getActiveSheet()->mergeCells('E26:F26');
                                       $excel->getActiveSheet()->setCellValue('E26','Tracking System Manual');
                                    $excel->getActiveSheet()->mergeCells('G26:I26');
                                     $excel->getActiveSheet()->setCellValue('G26','Yes');
                                      $excel->getActiveSheet()->mergeCells('E27:F27');
                                       $excel->getActiveSheet()->setCellValue('E27','');
                                    $excel->getActiveSheet()->mergeCells('G27:I27');
                                     $excel->getActiveSheet()->setCellValue('G27','');
                                      $excel->getActiveSheet()->mergeCells('E28:F28');
                                       $excel->getActiveSheet()->setCellValue('E28','HDPE Pipe(in mtr.)');
                                    $excel->getActiveSheet()->mergeCells('G28:I28');
                                     $excel->getActiveSheet()->setCellValue('G28','50 mtr');
                                      $excel->getActiveSheet()->mergeCells('E29:F29');
                                       $excel->getActiveSheet()->setCellValue('E29','');
                                    $excel->getActiveSheet()->mergeCells('G29:I29');
                                     $excel->getActiveSheet()->setCellValue('G29','');
                                      $excel->getActiveSheet()->mergeCells('E30:F30');
                                       $excel->getActiveSheet()->setCellValue('E30','Fiiting');
                                    $excel->getActiveSheet()->mergeCells('G30:I30');
                                     $excel->getActiveSheet()->setCellValue('G30','Satisfactory/Non-satisfactory');
                                      $excel->getActiveSheet()->mergeCells('E31:F31');
                                       $excel->getActiveSheet()->setCellValue('E31','');
                                    $excel->getActiveSheet()->mergeCells('G31:I31');
                                     $excel->getActiveSheet()->setCellValue('G31','');
                                      $excel->getActiveSheet()->mergeCells('E32:F32');
                                       $excel->getActiveSheet()->setCellValue('E32','Earthing System');
                                    $excel->getActiveSheet()->mergeCells('G32:I32');
                                     $excel->getActiveSheet()->setCellValue('G32','Yes');
                                      $excel->getActiveSheet()->mergeCells('E33:F33');
                                       $excel->getActiveSheet()->setCellValue('E33','');
                                    $excel->getActiveSheet()->mergeCells('G33:I33');
                                     $excel->getActiveSheet()->setCellValue('G33','');
                                      $excel->getActiveSheet()->mergeCells('E34:F34');
                                       $excel->getActiveSheet()->setCellValue('E34','Literature');
                                    $excel->getActiveSheet()->mergeCells('G34:I34');
                                     $excel->getActiveSheet()->setCellValue('G34','Provided/Not Provided');
                                      $excel->getActiveSheet()->mergeCells('E35:F35');
                                       $excel->getActiveSheet()->setCellValue('E35','');
                                    $excel->getActiveSheet()->mergeCells('G35:I35');
                                     $excel->getActiveSheet()->setCellValue('G35','');
                                      $excel->getActiveSheet()->mergeCells('E36:F36');
                                       $excel->getActiveSheet()->setCellValue('E36','Working explained to beneficiary');
                                    $excel->getActiveSheet()->mergeCells('G36:I36');
                                     $excel->getActiveSheet()->setCellValue('G36','Yes / No');
                                      $excel->getActiveSheet()->mergeCells('E37:F37');
                                       $excel->getActiveSheet()->setCellValue('E37','');
                                    $excel->getActiveSheet()->mergeCells('G37:I37');
                                     $excel->getActiveSheet()->setCellValue('G37','');
                                      $excel->getActiveSheet()->mergeCells('E38:F38');
                                       $excel->getActiveSheet()->setCellValue('E38','System is functioning satisfactory');
                                    $excel->getActiveSheet()->mergeCells('G38:I38');
                                     $excel->getActiveSheet()->setCellValue('G38','Yes / No');
                                      $excel->getActiveSheet()->mergeCells('E39:F40');
                                       $excel->getActiveSheet()->setCellValue('E39','Other if any:-');
                                       $excel->getActiveSheet()->getStyle('E39')->getAlignment()->setVertical('top');
    
                                    $excel->getActiveSheet()->mergeCells('G39:I40');
                                     $excel->getActiveSheet()->setCellValue('G39','Nill');
                                     $excel->getActiveSheet()->getStyle('G39')->getAlignment()->setVertical('top');
    

                                    
                                       $excel->getActiveSheet()->getStyle('E23:I40')->applyFromArray($styleBorder);

                                        $excel->getActiveSheet()->mergeCells('E41:I41');
                                    $excel->getActiveSheet()->setCellValue('E41','Date of Commiissioning:');

                            $excel->getActiveSheet()->setCellValue('A42','Farmer/Benificiary');
                            $excel->getActiveSheet()->setCellValue('E42','Representative of Form');
                             $excel->getActiveSheet()->setCellValue('G42','Representative of MPUVN');
                            $excel->getActiveSheet()->setCellValue('A44','Sign & Name');
                            $excel->getActiveSheet()->setCellValue('E44','Sign,Name & Seal Date');
                         //   $excel->getActiveSheet()->getStyle('E44'.$excel->getActiveSheet()->getHighestRow())
    //->getAlignment()->setWrapText(true); 
                            $excel->getActiveSheet()->setCellValue('G44','Sign, Name & Seal');










                                     //$excel->getActiveSheet()->getColumnDimension('G')->setWidth(10);




                                    





                              















                  $excel->getActiveSheet()->getStyle('A6:I42')->applyFromArray($styleFontBold3);



                  /*foreach($excel->getActiveSheet()->getColumnDimension() as $col) {
    $col->setAutoSize(true);
}*/




         



    /*$excel->getActiveSheet()->setCellValue('A9','Mob No:','');
    $excel->getActiveSheet()->setCellValue('A8','Name of Farmer:'.$dsfsdf);
    $excel->getActiveSheet()->setCellValue('A8','Name of Farmer:'.$dsfsdf);
*/
 	





 	 	
 	 	
 	 	









//$excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
/*$excel->getActiveSheet()->setCellValue('L1','Date:04-11-2018');
$excel->getActiveSheet()->getStyle('L1')->getAlignment()->setHorizontal('right');
$excel->getActiveSheet()->setCellValue('A2','Name of Farmer:');
$excel->getActiveSheet()->setCellValue('A3','Mob No:');
$excel->getActiveSheet()->setCellValue('A4','Category Of Farmer');
$excel->getActiveSheet()->setCellValue('A5','SPV Modules Array');
$excel->getActiveSheet()->setCellValue('A6','Total Solar Panel...16.....x.....300Wp');
$excel->getActiveSheet()->setCellValue('A7','Panel Manufacture:Gautam Solar Pvt. Ltd.');
$excel->getActiveSheet()->setCellValue('A8','S.No:');
$excel->getActiveSheet()->setCellValue('B8','Sr.No, of PV Module');
$excel->getActiveSheet()->setCellValue('A9','1');
$excel->getActiveSheet()->setCellValue('B9','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A10','2');
$excel->getActiveSheet()->setCellValue('B10','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A11','3');
$excel->getActiveSheet()->setCellValue('B11','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A12','4');
$excel->getActiveSheet()->setCellValue('B12','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A13','5');
$excel->getActiveSheet()->setCellValue('B13','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A14','6');
$excel->getActiveSheet()->setCellValue('B14','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A15','7');
$excel->getActiveSheet()->setCellValue('B15','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A16','8');
$excel->getActiveSheet()->setCellValue('B16','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A17','9');
$excel->getActiveSheet()->setCellValue('B17','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A18','10');
$excel->getActiveSheet()->setCellValue('B18','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A19','11');
$excel->getActiveSheet()->setCellValue('B19','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A20','12');
$excel->getActiveSheet()->setCellValue('B20','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A21','13');
$excel->getActiveSheet()->setCellValue('B21','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A22','14');
$excel->getActiveSheet()->setCellValue('B22','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A23','15');
$excel->getActiveSheet()->setCellValue('B23','SSGSO230025917');
$excel->getActiveSheet()->setCellValue('A24','16');
$excel->getActiveSheet()->setCellValue('B24','SSGSO230025917');*/

//$excel->getActiveSheet()->getStyle('A1:B2')->applyFromArray($styleArray);
//unset($styleArray);

/*$excel->getActiveSheet()->setCellValue('A1','Hello');	
$excel->getActiveSheet()->getStyle('A1:B2')->applyFromArray($styleArray);
unset($styleArray);
 


$excel->getActiveSheet()->getCell('A1')->setValue('Some text');
$excel->getActiveSheet()->getStyle('A1')->applyFromArray($styleArray1);


$excel->getActiveSheet()->getStyle('D1:D'.$excel->getActiveSheet()->getHighestRow())
    ->getAlignment()->setWrapText(true); 
*/

 // $excel->getActiveSheet()->mergeCells('A1:E1');

//redirect to browser (download) instead of saving the result as a file

//this is for MS Office Excel 2007 xlsx format
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="test.xlsx"');

//this is for MS Office Excel 2003 xls format
//header('Content-Type: application/vnd.ms-excel');
//header('Content-Disposition: attachment; filename="test.xlsx"');


header('Cache-Control: max-age=0');

//write the result to a file
//for excel 2007 format
$file = PHPExcel_IOFactory::createWriter($excel,'Excel2007');

//for excel 2003 format
//$file = PHPExcel_IOFactory::createWriter($excel,'Excel5');

//output to php output instead of filename
$file->save('php://output');

?>