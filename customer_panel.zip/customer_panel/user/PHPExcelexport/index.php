<?php
require_once 'Classes/PHPExcel.php';

$dsfsdf="Krishna Pal Yadav";

//create PHPExcel object
$excel = new PHPExcel();
$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle('Example');

$styleBorder = array(
  'borders' => array(
    'allborders' => array(
      'style' => PHPExcel_Style_Border::BORDER_THIN
  )
)
);
       
 $styleFontBold1 = array(
    'font'  => array(
        'bold'  => true,	
        'size'  => 13,	
        //'name'  => 'Verdana'
    ));
 $styleFontBold2 = array(
    'font'  => array(
        'bold'  => true,
        'size'  => 12,	
        //'name'  => 'Verdana'
    ));
  $styleFontBold3 = array(
    'font'  => array(
        
        'size'  => 10,  
        //'name'  => 'Verdana'
    ));
  $styleFontBold4 = array(
    'font'  => array(
        
        'size'  => 9,  
        //'name'  => 'Verdana'
    ));
   $styleFontBold5 = array(
    'font'  => array(
        
        'size'  => 8,  
        //'name'  => 'Verdana'
    ));
   $stylebold = array(
    'font'  => array(
        
       'bold'  => true, 
        //'name'  => 'Verdana'
    ));

//$excel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
 $excel->getActiveSheet()->mergeCells('A1:I1');

$excel->getActiveSheet()->setCellValue('A1','Details of Material Received for Solar Pumping System 2018-19');
//$excel->getActiveSheet()->getStyle('A1:L1')->applyFromArray($styleBorder);
$excel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($styleFontBold1);
$excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');

 $excel->getActiveSheet()->mergeCells('A3:E3');
 $excel->getActiveSheet()->setCellValue('A3','Name of Farmer');
  $excel->getActiveSheet()->mergeCells('A6:E6');
 $excel->getActiveSheet()->setCellValue('A6','SPV Modules/ Array');
  $excel->getActiveSheet()->getStyle('A6')->applyFromArray($stylebold);
 $excel->getActiveSheet()->getStyle('A6')->getAlignment()->setHorizontal('center');
 $excel->getActiveSheet()->mergeCells('F3:I3');
 $excel->getActiveSheet()->setCellValue('F3','Village');
 $excel->getActiveSheet()->mergeCells('F4:I4');
 $excel->getActiveSheet()->setCellValue('F4','Tehsil');
 $excel->getActiveSheet()->mergeCells('F5:I5');
 $excel->getActiveSheet()->setCellValue('F5','District');
 $excel->getActiveSheet()->mergeCells('F6:I6');
 $excel->getActiveSheet()->setCellValue('F6','Motor and Pump Details');
 $excel->getActiveSheet()->getStyle('F6')->applyFromArray($stylebold);

 $excel->getActiveSheet()->mergeCells('A7:E7');
 $excel->getActiveSheet()->setCellValue('A7','Invoice/bill/challan No & date');
 $excel->getActiveSheet()->mergeCells('A8:E8');
 $excel->getActiveSheet()->setCellValue('A8','Solar Panel 200/220/225/230/250/300/325 WP');
 $excel->getActiveSheet()->mergeCells('A9:E9');
 $excel->getActiveSheet()->setCellValue('A9','Panel Manufacturer:Gautam Solar Pvt. Ltd.');
 $excel->getActiveSheet()->getStyle('A7:E9')->applyFromArray($styleFontBold4);

 $excel->getActiveSheet()->setCellValue('A11','Module No');
 $excel->getActiveSheet()->mergeCells('B11:C11');
 $excel->getActiveSheet()->setCellValue('B11','Sr.No');
 $excel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
 $excel->getActiveSheet()->getStyle('B11')->getAlignment()->setHorizontal('center');
  $excel->getActiveSheet()->mergeCells('D11:E11');
 $excel->getActiveSheet()->setCellValue('D11','Peak wattage');
 $excel->getActiveSheet()->getColumnDimension('D')->setWidth(6);
 $excel->getActiveSheet()->getColumnDimension('E')->setWidth(5);

 $excel->getActiveSheet()->setCellValue('A12','1');
  $excel->getActiveSheet()->mergeCells('B12:C12');
 $excel->getActiveSheet()->setCellValue('B12','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D12:E12');
  $excel->getActiveSheet()->setCellValue('D12','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A13','2');
  $excel->getActiveSheet()->mergeCells('B13:C13');
 $excel->getActiveSheet()->setCellValue('B13','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D13:E13');
  $excel->getActiveSheet()->setCellValue('D13','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A14','3');
  $excel->getActiveSheet()->mergeCells('B14:C14');
 $excel->getActiveSheet()->setCellValue('B14','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D14:E14');
  $excel->getActiveSheet()->setCellValue('D14','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A15','4');
  $excel->getActiveSheet()->mergeCells('B15:C15');
 $excel->getActiveSheet()->setCellValue('B15','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D15:E15');
  $excel->getActiveSheet()->setCellValue('D15','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A16','5');
  $excel->getActiveSheet()->mergeCells('B16:C16');
 $excel->getActiveSheet()->setCellValue('B16','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D16:E16');
  $excel->getActiveSheet()->setCellValue('D16','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A17','6');
  $excel->getActiveSheet()->mergeCells('B17:C17');
 $excel->getActiveSheet()->setCellValue('B17','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D17:E17');
  $excel->getActiveSheet()->setCellValue('D17','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A18','7');
  $excel->getActiveSheet()->mergeCells('B18:C18');
 $excel->getActiveSheet()->setCellValue('B18','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D18:E18');
  $excel->getActiveSheet()->setCellValue('D18','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A19','8');
  $excel->getActiveSheet()->mergeCells('B19:C19');
 $excel->getActiveSheet()->setCellValue('B19','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D19:E19');
  $excel->getActiveSheet()->setCellValue('D19','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A20','9');
  $excel->getActiveSheet()->mergeCells('B20:C20');
 $excel->getActiveSheet()->setCellValue('B20','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D20:E20');
  $excel->getActiveSheet()->setCellValue('D20','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A21','10');
  $excel->getActiveSheet()->mergeCells('B21:C21');
 $excel->getActiveSheet()->setCellValue('B21','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D21:E21');
  $excel->getActiveSheet()->setCellValue('D21','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A22','11');
  $excel->getActiveSheet()->mergeCells('B22:C22');
 $excel->getActiveSheet()->setCellValue('B22','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D22:E22');
  $excel->getActiveSheet()->setCellValue('D22','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A23','12');
  $excel->getActiveSheet()->mergeCells('B23:C23');
 $excel->getActiveSheet()->setCellValue('B23','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D23:E23');
  $excel->getActiveSheet()->setCellValue('D23','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A24','13');
  $excel->getActiveSheet()->mergeCells('B24:C24');
 $excel->getActiveSheet()->setCellValue('B24','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D24:E24');
  $excel->getActiveSheet()->setCellValue('D24','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A25','14');
  $excel->getActiveSheet()->mergeCells('B25:C25');
 $excel->getActiveSheet()->setCellValue('B25','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D25:E25');
  $excel->getActiveSheet()->setCellValue('D25','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A26','15');
  $excel->getActiveSheet()->mergeCells('B26:C26');
 $excel->getActiveSheet()->setCellValue('B26','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D26:E26');
  $excel->getActiveSheet()->setCellValue('D26','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A27','16');
  $excel->getActiveSheet()->mergeCells('B27:C27');
 $excel->getActiveSheet()->setCellValue('B27','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D27:E27');
  $excel->getActiveSheet()->setCellValue('D27','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A28','17');
  $excel->getActiveSheet()->mergeCells('B28:C28');
 $excel->getActiveSheet()->setCellValue('B28','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D28:E28');
  $excel->getActiveSheet()->setCellValue('D28','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A29','18');
  $excel->getActiveSheet()->mergeCells('B29:C29');
 $excel->getActiveSheet()->setCellValue('B29','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D29:E29');
  $excel->getActiveSheet()->setCellValue('D29','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A30','19');
  $excel->getActiveSheet()->mergeCells('B30:C30');
 $excel->getActiveSheet()->setCellValue('B30','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D30:E30');
  $excel->getActiveSheet()->setCellValue('D30','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A31','20');
  $excel->getActiveSheet()->mergeCells('B31:C31');
 $excel->getActiveSheet()->setCellValue('B31','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D31:E31');
  $excel->getActiveSheet()->setCellValue('D31','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A32','21');
  $excel->getActiveSheet()->mergeCells('B32:C32');
 $excel->getActiveSheet()->setCellValue('B32','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D32:E32');
  $excel->getActiveSheet()->setCellValue('D32','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A33','22');
  $excel->getActiveSheet()->mergeCells('B33:C33');
 $excel->getActiveSheet()->setCellValue('B33','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D33:E33');
  $excel->getActiveSheet()->setCellValue('D33','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A34','23');
  $excel->getActiveSheet()->mergeCells('B34:C34');
 $excel->getActiveSheet()->setCellValue('B34','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D34:E34');
  $excel->getActiveSheet()->setCellValue('D34','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A35','24');
  $excel->getActiveSheet()->mergeCells('B35:C35');
 $excel->getActiveSheet()->setCellValue('B35','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D35:E35');
  $excel->getActiveSheet()->setCellValue('D35','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A36','25');
  $excel->getActiveSheet()->mergeCells('B36:C36');
 $excel->getActiveSheet()->setCellValue('B36','SGRUFJF948038393843');
   $excel->getActiveSheet()->mergeCells('D36:E36');
  $excel->getActiveSheet()->setCellValue('D36','sdfsfsf');

   $excel->getActiveSheet()->setCellValue('A37','');
  $excel->getActiveSheet()->mergeCells('B37:C37');
 $excel->getActiveSheet()->setCellValue('B37','Total Wattgae');
 $excel->getActiveSheet()->getStyle('B37')->getAlignment()->setHorizontal('center');
   $excel->getActiveSheet()->mergeCells('D37:E37');
  $excel->getActiveSheet()->setCellValue('D37','');
   $excel->getActiveSheet()->getStyle('A11:E37')->applyFromArray($styleBorder);
    $excel->getActiveSheet()->getStyle('A11:E37')->applyFromArray($styleFontBold4);

   /*part two*/

     $excel->getActiveSheet()->setCellValue('F7','Type');
       $excel->getActiveSheet()->mergeCells('G7:I7');
        $excel->getActiveSheet()->setCellValue('G7','Submersible/Centrifugal Surface Pump');
         $excel->getActiveSheet()->setCellValue('F8','AC/DC');
       $excel->getActiveSheet()->mergeCells('G8:I8');
        $excel->getActiveSheet()->setCellValue('G8','');

 $excel->getActiveSheet()->setCellValue('F9','HP');
       $excel->getActiveSheet()->mergeCells('G9:I9');
        $excel->getActiveSheet()->setCellValue('G9','');
         $excel->getActiveSheet()->mergeCells('F10:I10');
           $excel->getActiveSheet()->setCellValue('F10','Head 20/50/75/100(in Mtr.)');
            $excel->getActiveSheet()->mergeCells('F11:I11');
           $excel->getActiveSheet()->setCellValue('F11','Make & Model');

           $excel->getActiveSheet()->setCellValue('F12','Sr.No');
         $excel->getActiveSheet()->mergeCells('G12:I12');
           $excel->getActiveSheet()->setCellValue('G12','');
            $excel->getActiveSheet()->mergeCells('F13:I13');
           $excel->getActiveSheet()->setCellValue('F13','Domestic light system Yes/No. Sr.no....');


           $excel->getActiveSheet()->setCellValue('F14','Yes/No');
         $excel->getActiveSheet()->mergeCells('G14:I14');
           $excel->getActiveSheet()->setCellValue('G14','37 Wp module with 40 Ah battery / 9Wx2 fixture');
           

           $excel->getActiveSheet()->setCellValue('F15','Fencing');
         $excel->getActiveSheet()->mergeCells('G15:I15');
           $excel->getActiveSheet()->setCellValue('G15','Yes/No');

            $excel->getActiveSheet()->getStyle('F7:I15')->applyFromArray($styleBorder);
            $excel->getActiveSheet()->getStyle('F7:I15')->applyFromArray($styleFontBold4);
            $excel->getActiveSheet()->getStyle('G14')->applyFromArray($styleFontBold5);
            $excel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
            $excel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
            $excel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
              $excel->getActiveSheet()->getColumnDimension('F')->setWidth(15);

      $excel->getActiveSheet()->mergeCells('F16:I16');
      $excel->getActiveSheet()->setCellValue('F16','Other Details');
      $excel->getActiveSheet()->mergeCells('F17:I17');
      $excel->getActiveSheet()->setCellValue('F17','Water Source: Diggi/Tank/Pond/WHS/Well/TW');



      $excel->getActiveSheet()->setCellValue('F18','Controller');
      $excel->getActiveSheet()->mergeCells('G18:I18');
      $excel->getActiveSheet()->setCellValue('G18','Make');
      $excel->getActiveSheet()->setCellValue('F19','Sr.No.');
      $excel->getActiveSheet()->mergeCells('G19:I19');
      $excel->getActiveSheet()->setCellValue('G19','');
      $excel->getActiveSheet()->setCellValue('F20','');
      $excel->getActiveSheet()->mergeCells('G20:I20');
      $excel->getActiveSheet()->setCellValue('G20','');
       $excel->getActiveSheet()->mergeCells('F21:I21');
       $excel->getActiveSheet()->setCellValue('F21','GI Support /Tracking System');
          $excel->getActiveSheet()->getStyle('F21')->applyFromArray($stylebold);

          $excel->getActiveSheet()->setCellValue('F22','');
      $excel->getActiveSheet()->mergeCells('G22:I22');
      $excel->getActiveSheet()->setCellValue('G22','Manual/Auto Tracker');
      $excel->getActiveSheet()->setCellValue('F23','');
      $excel->getActiveSheet()->mergeCells('G23:I23');
      $excel->getActiveSheet()->setCellValue('G23','.........');
      $excel->getActiveSheet()->setCellValue('F24','HDPE Pipe');
      $excel->getActiveSheet()->mergeCells('G24:I24');
      $excel->getActiveSheet()->setCellValue('G24','Make......(in mtr)...');
      $excel->getActiveSheet()->setCellValue('F25','');
      $excel->getActiveSheet()->mergeCells('G25:I25');
      $excel->getActiveSheet()->setCellValue('G25','');
      $excel->getActiveSheet()->setCellValue('F26','Cable');
      $excel->getActiveSheet()->mergeCells('G26:I26');
      $excel->getActiveSheet()->setCellValue('G26','Length....Mts');
      $excel->getActiveSheet()->setCellValue('F27','');
      $excel->getActiveSheet()->mergeCells('G27:I27');
      $excel->getActiveSheet()->setCellValue('G27','Single core IS/......Make.....');
      $excel->getActiveSheet()->setCellValue('F28','');
      $excel->getActiveSheet()->mergeCells('G28:I28');
      $excel->getActiveSheet()->setCellValue('G28','');
      $excel->getActiveSheet()->setCellValue('F29','DC Switch');
      $excel->getActiveSheet()->mergeCells('G29:I29');
      $excel->getActiveSheet()->setCellValue('G29','Yes/No .......');
      $excel->getActiveSheet()->setCellValue('F30','');
      $excel->getActiveSheet()->mergeCells('G30:I30');
      $excel->getActiveSheet()->setCellValue('G30','');
      $excel->getActiveSheet()->setCellValue('F31','Fitting');
      $excel->getActiveSheet()->mergeCells('G31:I31');
      $excel->getActiveSheet()->setCellValue('G31','Satisfactory/Non-satisfactory');
      $excel->getActiveSheet()->setCellValue('F32','');
      $excel->getActiveSheet()->mergeCells('G32:I32');
      $excel->getActiveSheet()->setCellValue('G32','');
        $excel->getActiveSheet()->mergeCells('F33:I33');
           $excel->getActiveSheet()->setCellValue('F33','Float system : Yes/No........');

            $excel->getActiveSheet()->setCellValue('F34','');
      $excel->getActiveSheet()->mergeCells('G34:I34');
      $excel->getActiveSheet()->setCellValue('G34','');

       $excel->getActiveSheet()->setCellValue('F35','Literature');
      $excel->getActiveSheet()->mergeCells('G35:I35');
      $excel->getActiveSheet()->setCellValue('G35','Provided / Not Provided');
       $excel->getActiveSheet()->setCellValue('F36','Remote Monitoring');
      $excel->getActiveSheet()->mergeCells('G36:I36');
      $excel->getActiveSheet()->setCellValue('G36','Provided / Not Provided');
       $excel->getActiveSheet()->setCellValue('F37','Others if any');
      $excel->getActiveSheet()->mergeCells('G37:I37');
      $excel->getActiveSheet()->setCellValue('G37','');
       $excel->getActiveSheet()->getStyle('F18:I37')->applyFromArray($styleBorder);
            $excel->getActiveSheet()->getStyle('F18:I37')->applyFromArray($styleFontBold4);
         $excel->getActiveSheet()->mergeCells('A39:I39');
             $excel->getActiveSheet()->setCellValue('A39','Date of Supply............');
               $excel->getActiveSheet()->mergeCells('F40:I40');
             $excel->getActiveSheet()->setCellValue('F40','Representative of Firm.......');
             $excel->getActiveSheet()->mergeCells('A41:I41');
             $excel->getActiveSheet()->setCellValue('A41','Signature');
             $excel->getActiveSheet()->mergeCells('A43:E43');
             $excel->getActiveSheet()->setCellValue('A43','Farmer/Beneficiary........');
             $excel->getActiveSheet()->mergeCells('F43:I43');
             $excel->getActiveSheet()->setCellValue('F43','AAO/AO/AD/DD(With seal)........');

             $excel->getActiveSheet()->mergeCells('A45:I45');
             $excel->getActiveSheet()->setCellValue('A45','Mobile No');


















   































//this is for MS Office Excel 2007 xlsx format
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="test.xlsx"');

//this is for MS Office Excel 2003 xls format
//header('Content-Type: application/vnd.ms-excel');
//header('Content-Disposition: attachment; filename="test.xlsx"');


header('Cache-Control: max-age=0');

//write the result to a file
//for excel 2007 format
$file = PHPExcel_IOFactory::createWriter($excel,'Excel2007');

//for excel 2003 format
//$file = PHPExcel_IOFactory::createWriter($excel,'Excel5');

//output to php output instead of filename
$file->save('php://output');

?>