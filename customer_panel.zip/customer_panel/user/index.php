<?php session_start();
require_once 'PHPExcelexport/Classes/PHPExcel.php';
include('include/config.php');
 if(strlen($_SESSION['alogin'])==0)
	{	
  header('location:../pages-login.php');
    }
  $username=$_SESSION['alogin'];

                                  if(isset($_POST['submit']))
                                  {
                                    $zone = $_POST['zone'];
									
	                                $zone_new =  explode(",",$zone);
	                                $zone_id_new =  $zone_new[0];
	                              
									$state = $_POST['state'];
									$district_se = $_POST['district'];
									
									$status_se = $_POST['status'];
									$constituency = $_POST['constituency'];
								    $cons =  explode(",",$constituency);
	              					$cons_name =  $cons[2];

									$fdate = $_POST['fdate'];
									$tdate = $_POST['tdate'];
									
									$whereClauses1 = array(); 
                       if (! empty($_POST['fdate']) and ! empty($_POST['tdate']) ) 
					   {
                        $whereClauses1[] ="CONVERT(VARCHAR(10),reg_date,121) BETWEEN '".$_POST['fdate']."' and '".$_POST['tdate']."' ";
						   $where1 = ''; 
					   }
									if(! empty($_POST['fdate']) and empty($_POST['tdate']) ) {
			$whereClauses1[] ="CONVERT(VARCHAR(10),reg_date,121) BETWEEN '".$_POST['fdate']."' and '".$_POST['fdate']."' ";	
									$where1 = ''; 
									}
									if( empty($_POST['fdate']) and ! empty($_POST['tdate']) ) {
			$whereClauses1[] ="CONVERT(VARCHAR(10),reg_date,121) BETWEEN '".$_POST['tdate']."' and '".$_POST['tdate']."' ";	
									$where1 = ''; 
									}

          

						if (! empty($_POST['state'])) 
						  $whereClauses1[] ="state_id='".$_POST['state']."'"; 
						$where1 = ''; 

						if (! empty($zone_id_new)) 
						  $whereClauses1[] ="zone_id='".$zone_id_new."'"; 
						$where1 = ''; 
						 if (! empty($_POST['district'])) 
						  $whereClauses1[] ="district_id='".$_POST['district']."'"; 
						$where1 = ''; 

						 if (! empty($_POST['status'])) 
						  $whereClauses1[] ="status='".$_POST['status']."'"; 
						$where1 = ''; 

						if (! empty($cons_name)) 
						  $whereClauses1[] ="constituency='".$cons_name."'"; 
						$where1 = ''; 

						if (count($whereClauses1) > 0) 
						{ 
						   $where1 = ' WHERE '.implode(' AND ',$whereClauses1); 
						} 


//create PHPExcel object
$excel = new PHPExcel();
$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle('Example');

$styleBorder = array(
  'borders' => array(
    'allborders' => array(
      'style' => PHPExcel_Style_Border::BORDER_THIN
  )
)
);
       
 $styleFontBold1 = array(
    'font'  => array(
        'bold'  => true,	
        'size'  => 13,	
        
    ));
 $styleFontBold2 = array(
    'font'  => array(
        'bold'  => true,
        'size'  => 12,	
        
    ));
  $styleFontBold3 = array(
    'font'  => array(
         'bold'  => true,
        'size'  => 10,  
        
    ));

        
   $styleFontBold5 = array(
    'font'  => array(
        
        'size'  => 8,  
       
    ));
   $stylebold = array(
    'font'  => array(
        
       'bold'  => true, 
        
    ));



// $excel->getActiveSheet()->setCellValue('A1','परिशिष्ठ - 8 II');

 $excel->getActiveSheet()->setCellValue('A1','OUR NUMBER');
  $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
 $excel->getActiveSheet()->setCellValue('B1','NAME');
  $excel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
$excel->getActiveSheet()->setCellValue('C1','FATHER NAME');
  $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
$excel->getActiveSheet()->setCellValue('D1','MOBILE NUMBER');
  $excel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
$excel->getActiveSheet()->setCellValue('E1','STATE');
    $excel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
    $excel->getActiveSheet()->setCellValue('F1','DISTRICT');
    $excel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
    $excel->getActiveSheet()->setCellValue('G1','CONSTITUENCY');
    $excel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
    $excel->getActiveSheet()->setCellValue('H1','ZONE');
    $excel->getActiveSheet()->getColumnDimension('H')->setWidth(25);
    $excel->getActiveSheet()->setCellValue('I1','GRAM PANCHAYAT');
    $excel->getActiveSheet()->getColumnDimension('I')->setWidth(25);
    $excel->getActiveSheet()->setCellValue('J1','BLOCK');
    $excel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
    $excel->getActiveSheet()->setCellValue('K1','VILLAGE');
    $excel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
    $excel->getActiveSheet()->setCellValue('L1','DATE OF INSTALLATION');
    $excel->getActiveSheet()->getColumnDimension('L')->setWidth(30);
    $excel->getActiveSheet()->setCellValue('M1','PINCODE');
    $excel->getActiveSheet()->getColumnDimension('M')->setWidth(30);
	$excel->getActiveSheet()->setCellValue('N1','Address');
    $excel->getActiveSheet()->getColumnDimension('N')->setWidth(30);
    $excel->getActiveSheet()->setCellValue('O1','ENG NAME');
    $excel->getActiveSheet()->getColumnDimension('O')->setWidth(30);
	$excel->getActiveSheet()->setCellValue('P1','UID NO');
    $excel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
	$excel->getActiveSheet()->setCellValue('Q1','PROJECT NAME');
    $excel->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
	$excel->getActiveSheet()->setCellValue('R1','PRITINIDHI NAME');
    $excel->getActiveSheet()->getColumnDimension('R')->setWidth(30);
	$excel->getActiveSheet()->setCellValue('S1','PRITINIDHI MOB');
    $excel->getActiveSheet()->getColumnDimension('S')->setWidth(30);
	$excel->getActiveSheet()->setCellValue('T1','STATUS');
    $excel->getActiveSheet()->getColumnDimension('T')->setWidth(30);
									  
    $excel->getActiveSheet()->setCellValue('U1','SITE UPDATE STATUS');
    $excel->getActiveSheet()->getColumnDimension('U')->setWidth(30);
    $excel->getActiveSheet()->setCellValue('V1','INSTALLER NAME');
    $excel->getActiveSheet()->getColumnDimension('V')->setWidth(30);
    $excel->getActiveSheet()->setCellValue('W1','INSTALLER MOBILE');
    $excel->getActiveSheet()->getColumnDimension('W')->setWidth(30);

    $excel->getActiveSheet()->getStyle('A1:W1')->applyFromArray($styleFontBold3);
    $excel->getActiveSheet()->getStyle('A1:W1')->applyFromArray($styleBorder);

   $query = " SELECT CONVERT(varchar(10),instalation_date,121) as instdate , village,block,our_number,
 constituency,dist_name,zone_name,status,pincode,gram_panchayat,contact,registered_by,state_name ,project_name, uid_no,
  beneficiary_fname,   beneficiary_name ,pratinidhi_name ,site_update_status,installer_name,installer_mobile,
	 pratinidhi_mob  , contact, address from
	 [cmsDBNew].[dbo].[eesl_streetlight] $where1 and project_name = '2017-18 AJAY SCHEME EESL PHASE 1'  ORDER by id desc ";
		
	 $params=array();
     $options=array("Scrollable" => SQLSRV_CURSOR_KEYSET);

    $result = mysqli_query($con,$query, $params, $options);
    									  
  
	$rowcount=2;
								  
    while($row = mysqli_fetch_array($result)) {
	
	
	$excel->getActiveSheet()->setCellValue('A'.$rowcount, $row['our_number']);
    $excel->getActiveSheet()->setCellValue('B'.$rowcount, $row['beneficiary_name']);
    $excel->getActiveSheet()->setCellValue('C'.$rowcount, $row['beneficiary_fname']);
	  $excel->getActiveSheet()->setCellValue('D'.$rowcount, $row['contact']);
    $excel->getActiveSheet()->setCellValue('E'.$rowcount, $row['state_name']);
	  $excel->getActiveSheet()->setCellValue('F'.$rowcount, $row['dist_name']);
    $excel->getActiveSheet()->setCellValue('G'.$rowcount, $row['constituency']);
	  $excel->getActiveSheet()->setCellValue('H'.$rowcount, $row['zone_name']);
    $excel->getActiveSheet()->setCellValue('I'.$rowcount, $row['gram_panchayat']);
	  $excel->getActiveSheet()->setCellValue('J'.$rowcount, $row['block']);
    $excel->getActiveSheet()->setCellValue('K'.$rowcount, $row['village']);
	  $excel->getActiveSheet()->setCellValue('L'.$rowcount, $row['instdate']);
    $excel->getActiveSheet()->setCellValue('M'.$rowcount, $row['pincode']);
	 $excel->getActiveSheet()->setCellValue('N'.$rowcount, $row['address']);
	 $excel->getActiveSheet()->setCellValue('O'.$rowcount, $row['registered_by']);
	 $excel->getActiveSheet()->setCellValue('P'.$rowcount, $row['uid_no']);
	 $excel->getActiveSheet()->setCellValue('Q'.$rowcount, $row['project_name']);
	 $excel->getActiveSheet()->setCellValue('R'.$rowcount, $row['pratinidhi_name']);
	 $excel->getActiveSheet()->setCellValue('S'.$rowcount, $row['pratinidhi_mob']);
	 $excel->getActiveSheet()->setCellValue('T'.$rowcount, $row['status']);
	
	$excel->getActiveSheet()->setCellValue('U'.$rowcount, $row['site_update_status']);
	$excel->getActiveSheet()->setCellValue('V'.$rowcount, $row['installer_name']);
	$excel->getActiveSheet()->setCellValue('W'.$rowcount, $row['installer_mobile']);
	
	
	$rowcount++;
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8');
header('Content-Disposition: attachment; filename="eesl_streetlight_reportnew.xlsx"');

header('Cache-Control: max-age=0');

$file = PHPExcel_IOFactory::createWriter($excel,'Excel2007');

$file->save('php://output');




									  
 }

?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Gautam Solar | </title>

    <link href="../assets/common/img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
    <link href="../assets/common/img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
    <link href="../assets/common/img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
    <link href="../assets/common/img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
    <link href="../assets/common/img/favicon.png" rel="icon" type="image/png">
    <link href="favicon.ico" rel="shortcut icon">

    <!-- HTML5 shim and Respond.js for < IE9 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Vendors Styles -->
    <!-- v1.0.0 -->
    <link rel="stylesheet" type="text/css" href="../assets/vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/jscrollpane/style/jquery.jscrollpane.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/ladda/dist/ladda-themeless.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/select2/dist/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/fullcalendar/dist/fullcalendar.min.css">
   <!-- <link rel="stylesheet" type="text/css" href="../assets/vendors/cleanhtmlaudioplayer/src/player.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/cleanhtmlvideoplayer/src/player.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/bootstrap-sweetalert/dist/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/summernote/dist/summernote.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/owl.carousel/dist/assets/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/ionrangeslider/css/ion.rangeSlider.css">-->
    <link rel="stylesheet" type="text/css" href="../assets/vendors/datatables/media/css/dataTables.bootstrap4.min.css">
  <!--  <link rel="stylesheet" type="text/css" href="../assets/vendors/c3/c3.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendors/chartist/dist/chartist.min.css"> -->

    <!-- Clean UI Styles -->
    <link rel="stylesheet" type="text/css" href="../assets/common/css/source/main.css">

    <!-- Vendors Scripts -->
    <!-- v1.0.0 -->
   <!-- <script src="../assets/vendors/jquery/jquery.min.js"></script> -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
	<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="../assets/vendors/tether/dist/js/tether.min.js"></script>
    <script src="../assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../assets/vendors/jquery-mousewheel/jquery.mousewheel.min.js"></script>
    <script src="../assets/vendors/jscrollpane/script/jquery.jscrollpane.min.js"></script>
    <script src="../assets/vendors/spin.js/spin.js"></script>
    <script src="../assets/vendors/ladda/dist/ladda.min.js"></script>
    <script src="../assets/vendors/select2/dist/js/select2.full.min.js"></script>
    <script src="../assets/vendors/html5-form-validation/dist/jquery.validation.min.js"></script>
    <script src="../assets/vendors/jquery-typeahead/dist/jquery.typeahead.min.js"></script>
    <script src="../assets/vendors/jquery-mask-plugin/dist/jquery.mask.min.js"></script>
    <script src="../assets/vendors/autosize/dist/autosize.min.js"></script>
    <script src="../assets/vendors/bootstrap-show-password/bootstrap-show-password.min.js"></script>
    <script src="../assets/vendors/moment/min/moment.min.js"></script>
    <script src="../assets/vendors/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
    <script src="../assets/vendors/fullcalendar/dist/fullcalendar.min.js"></script> 
  <!--  <script src="../assets/vendors/cleanhtmlaudioplayer/src/jquery.cleanaudioplayer.js"></script>
    <script src="../assets/vendors/cleanhtmlvideoplayer/src/jquery.cleanvideoplayer.js"></script>
    <script src="../assets/vendors/bootstrap-sweetalert/dist/sweetalert.min.js"></script>
    <script src="../assets/vendors/remarkable-bootstrap-notify/dist/bootstrap-notify.min.js"></script>
    <script src="../assets/vendors/summernote/dist/summernote.min.js"></script>
    <script src="../assets/vendors/owl.carousel/dist/owl.carousel.min.js"></script>
    <script src="../assets/vendors/ionrangeslider/js/ion.rangeSlider.min.js"></script>-->
    <script src="../assets/vendors/nestable/jquery.nestable.js"></script>
    <script src="../assets/vendors/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../assets/vendors/datatables/media/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/vendors/datatables-fixedcolumns/js/dataTables.fixedColumns.js"></script>
    <script src="../assets/vendors/datatables-responsive/js/dataTables.responsive.js"></script>
    <!--<script src="../assets/vendors/editable-table/mindmup-editabletable.js"></script>-->
  <!--  <script src="../assets/vendors/d3/d3.min.js"></script>
    <script src="../assets/vendors/c3/c3.min.js"></script>
    <script src="../assets/vendors/chartist/dist/chartist.min.js"></script>
    <script src="../assets/vendors/peity/jquery.peity.min.js"></script> 
  
    <script src="../assets/vendors/chartist-plugin-tooltip/dist/chartist-plugin-tooltip.min.js"></script>
   
    <script src="../assets/vendors/gsap/src/minified/TweenMax.min.js"></script>
    <script src="../assets/vendors/hackertyper/hackertyper.js"></script> -->
    <script src="../assets/vendors/jquery-countTo/jquery.countTo.js"></script>

    <!-- Clean UI Scripts -->
    <script src="../assets/common/js/common.js"></script>
    <script src="../assets/common/js/demo.temp.js"></script>
	<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
})
</script>
	<script language="javascript" type="text/javascript">
var popUpWin=0;
function popUpWindow(URLStr, left, top, width, height)
{
 if(popUpWin)
{
if(!popUpWin.closed) popUpWin.close();
}
popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+600+',height='+600+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}

</script>
	
	
	
	<style>
.loader 
{
 position: fixed;
 left: 0px;
 top: 0px;
 width: 100%;
 height: 100%;
 z-index: 9999;
 background: url('signture_image/loader.gif') 50% 50% no-repeat rgb(249,249,249);
}
		
		.widget-seven .widget-body
		{
		height:81px !important;
		}
</style>
</head>
	<div class="loader"></div>
<body class="theme-default">
<!--header here-->
	<!--Header file HERE-->
	<?php include('header.php'); ?>
	<!-- END OF  HEADER FILE HERE-->

<section class="page-content">
<div class="page-content-inner">

    <!-- Dashboard -->
    <div class="dashboard-container">
       
        <div class="row">
            
            
        </div>
        <div class="row">
            <div class="col-xl-3 col-lg-6 col-sm-6 col-xs-12">
                <div class="widget widget-seven">
                    <div class="carousel-widget carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <div class="widget-body">
                                    <div class="widget-body-icon">
                                        <i class="icmn-accessibility"></i>
                                    </div>
									 
									<a href="exportdataall.php" class="widget-body-inner">
                                       
                                        <p>Total Excel Download</p>
                                    </a>
									 
                                   
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="widget-body">
                                    <div class="widget-body-icon">
                                        <i class="icmn-download"></i>
                                    </div>
									
                                    <a href="exportdataall.php" class="widget-body-inner">
                                        
                                        <p>Total Excel Download</p>
                                    </a>
									
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			 <div class="col-xl-3 col-lg-6 col-sm-6 col-xs-12">
                <div class="widget widget-seven background-info" style="background-image: url(../assets/common/img/temp/photos/9.jpeg)">
                    <div class="carousel-widget-2 carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <a href="#" class="widget-body">
                                    <h6>Complete</h6>
                                    <p>
                                       <?php
		    $constituency_check = $_POST['constituency'];
		   $cons =  explode(",",$constituency_check);
	        $cons_name =  $cons[2];
										
			
		 if ($cons_name != '')
			{
			
				$sqlpartial= mysqli_query($con," SELECT  count(status) as completed FROM [cmsDBNew].[dbo].[eesl_streetlight] where constituency =  '$cons_name' and status = 'COMPLETED' and project_name = '2017-18 AJAY SCHEME EESL PHASE 1'  ");

	 $sqlpartial1=mysqli_fetch_array($sqlpartial);
                
		echo  $Completed =  $sqlpartial1['completed']; 
				
				
			}
										
			
			
			else  
			{
			
				$sqlpartial= mysqli_query($con," SELECT  count(status) as completed FROM [cmsDBNew].[dbo].[eesl_streetlight] where  status = 'COMPLETED' and project_name = '2017-18 AJAY SCHEME EESL PHASE 1'  ");

	 $sqlpartial1=mysqli_fetch_array($sqlpartial);
                
		echo  $Completed =  $sqlpartial1['completed']; 
				
				
			}							
										
				
				?>
                                    </p>
                                </a>
                            </div>
                         
                        </div>
                    </div>
                </div>
            </div>
			<div class="col-xl-3 col-lg-6 col-sm-6 col-xs-12">
                <div class="widget widget-seven background-danger">
                    <div class="carousel-widget carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <a href="#" class="widget-body">
                                    <h6>
                                        <i class="icmn-books"></i> Partial Completed
                                    </h6>
                                    <p>
                                        <?php
		                          
		    $constituency_check = $_POST['constituency'];
		   $cons =  explode(",",$constituency_check);
	        $cons_name =  $cons[2];
			if($cons_name != '' )
			{
				$sqlpartial= mysqli_query($con," SELECT  count(status) as partial FROM [cmsDBNew].[dbo].[eesl_streetlight] where constituency =  '$cons_name' and status = 'PARTIAL COMPLETED' and project_name = '2017-18 AJAY SCHEME EESL PHASE 1' ");

	 $sqlpartial1=mysqli_fetch_array($sqlpartial);
                
		echo  $partiail =  $sqlpartial1['partial'];
			
			}
			else
			{
			
				$sqlpartial= mysqli_query($con," SELECT  count(status) as partial FROM [cmsDBNew].[dbo].[eesl_streetlight] where  status = 'PARTIAL COMPLETED' and project_name = '2017-18 AJAY SCHEME EESL PHASE 1'  ");

	 $sqlpartial1=mysqli_fetch_array($sqlpartial);
                
		echo  $partiail =  $sqlpartial1['partial']; 
				
				
			}
				
				?>
                                    </p>
                                </a>
                            </div>
                         
                        </div>
                    </div>
                </div>
            </div>
           <div class="col-xl-3 col-lg-6 col-sm-6 col-xs-12">
                <div class="widget widget-seven">
                    <div class="carousel-widget-2 carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <a href="#" class="widget-body">
                                    <h6>
                                     INCOMPLETE
                                    </h6><p><?php
		            $constituency_check = $_POST['constituency'];
		   $cons =  explode(",",$constituency_check);
	        $cons_name =  $cons[2];
			if($cons_name != '' )
			{
				$sqlincom= mysqli_query($con," SELECT  count(status) as incomplete FROM [cmsDBNew].[dbo].[eesl_streetlight] where constituency =  '$cons_name' and status = 'INCOMPLETE' and project_name = '2017-18 AJAY SCHEME EESL PHASE 1' ");

	 $sqlincom1=mysqli_fetch_array($sqlincom);
                
		echo  $incomplete =  $sqlincom1['incomplete'];
			
			}
			else
			{
			
				$sqlincom= mysqli_query($con," SELECT  count(status) as incomplete FROM [cmsDBNew].[dbo].[eesl_streetlight] where status = 'INCOMPLETE' and project_name = '2017-18 AJAY SCHEME EESL PHASE 1' ");

	 $sqlincom1=mysqli_fetch_array($sqlincom);
                
		echo  $incomplete =  $sqlincom1['incomplete']; 
				
				
			}
				
				?></p>
                                   
                                </a>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
            
           
        </div>
                           <div class="row">
                         <div class="col-xl-12 col-sm-12 col-lg-12">
					      <form method="post"  class="form-group">
							  
						 <div class="col-lg-2 col-sm-2 col-md-2">
                                    <div class="form-group">
                                       
                                        <input type="text" class="form-control" placeholder="Customer Name" name="customer_name" id="customer_name" autofocus>
                                    </div>
                          </div>
					
				
							  
			
							  
		  </div>
		</div>
					     <div class="row">
                         <div class="col-xl-12 col-sm-12 col-lg-12">
					   
					
							 
				
						
						      
						
						<div class="col-lg-2 col-sm-2">
						 <input type="submit" name="search" id="search" value="Search" class="form-control" />
					    </div>
						   <div class="col-lg-2 col-sm-2">
					 <button type="submit" name="submit"  class="btn btn-primary width-150">Download</button>
					    </div>
					   </form>
            
         
        
                      </div>
		</div>
      
    </div>
	
	
    <div class="row">
        <div class="col-xl-12">
            <div class="panel panel-with-borders">
                <div class="panel-body">
                    <div class="nav-tabs-horizontal margin-bottom-20">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" href="#h1" data-toggle="tab" data-target="#h1" role="tab">PHASE 1 DETAILS</a>
                            </li>
                           
                       
                        </ul>
                    </div>
					 <div class="tab-content">
						  <div role="tabpanel" class="tab-pane active" id="h1">
							 
							   <table style= "font-size:10px !important;" class="table table-hover nowrap margin-bottom-0" id="example1" width="100%">
                        <thead>
                        <tr>
							
                          <th>Customer Id </th>
                          <th>Customer Name</th>
					      <th>Mobile Number</th> 
						  <th>Vehicle Name</th>
			               <th>Edit</th>
							
                           
                        </tr>
                        </thead>
                        
                        <tbody>
							 <?php 

								if(isset($_POST['search']))
								{
									$customer_name = $_POST['customer_name'];
									
	                              
									
									$whereClauses = array(); 
                      
									

          

      
									 if (! empty($_POST['customer_name'])) 
                        $whereClauses[] ="customer_name like '%".$_POST['customer_name']."%'"; 
                        $where = ''; 
									
		              

                         if (count($whereClauses) > 0) 
        {  
         echo  $where = ' WHERE '.implode(' AND ',$whereClauses); 
        } 
									
							     
				$sqltable1= mysqli_query($con," SELECT cid , customer_name , mobile_number ,vechile_name FROM customerdata c inner JOIN vechile_type v 
                    on v.vechile_id = c.vechile_id $where ");
									
								

	 while($rowtable1=mysqli_fetch_array($sqltable1))
                {
		
		

?>
                        <tr>
							
						  <td><?php echo $rowtable1['cid']; ?></td>
                           
                            <td><?php echo $rowtable1['customer_name']; ?></td>
                            
                            
                            <td><?php echo $rowtable1['mobile_number']; ?></td>
                            
                            <td><?php echo $rowtable1['vechile_name']; ?></td>
                        
								 <td><a  target = "_BLANK" href="beneficiery_update_new.php?cid=<?php echo htmlentities($rowtable1['our_number']);?>"><button class="btn btn-info btn-sm">Edit</button></a></td>  
							
							
                        </tr>
                        
                      <?php }}
								
						 else{	
									
						$sqltable1= mysqli_query($con," 
 SELECT cid , customer_name , mobile_number , v.vechile_name FROM customerdata c inner JOIN vechile_type v on v.vechile_id = c.vechile_id ");

	 while($rowtable1=mysqli_fetch_array($sqltable1))
                {
		 
								?>
                        <tr>
							
							  <td><?php echo $rowtable1['cid']; ?></td>
                           
							<td><?php echo $rowtable1['customer_name']; ?></td>
							
                            
							<td><?php echo $rowtable1['mobile_number']; ?></td>
							
							<td><?php echo $rowtable1['vechile_name']; ?></td>
							
                          
                           
                   <td><a  target = "_BLANK" href="beneficiery_update_new.php?cid=<?php echo htmlentities($rowtable1['our_number']);?>"><button class="btn btn-info btn-sm">Edit</button></a></td>  
            
                        </tr>
                        
                      <?php } }?>
                        </tbody>
                    </table>
							  
						 </div>
										 
						 
						 
					</div>
				
					
                </div>
            </div>
        </div>
    </div>
    <!-- End Dashboard -->

</div>

<script type="text/javascript" src="main1.js"></script>
<!-- Page Scripts -->
<script>
	
	
	$(document).ready(function() {  
   $.datepicker.setDefaults({  
	   changeMonth: true,
        changeYear: true,
	   yearRange: '2016:2019',
        dateFormat: 'yy-mm-dd'   
   });  
   $(function(){  
     $("#fdate").datepicker();
	     $("#tdate").datepicker();
	 //  $("#com_date").datepicker();
	    
   });    
  }); 
	
    $(function() {

        ///////////////////////////////////////////////////////////
        // COUNTERS
        $('.counter-init').countTo({
            speed: 1500
        });

        ///////////////////////////////////////////////////////////
        // ADJUSTABLE TEXTAREA
        autosize($('#textarea'));

        ///////////////////////////////////////////////////////////
        // CUSTOM SCROLL
        if (!cleanUI.hasTouch) {
            $('.custom-scroll').each(function() {
                $(this).jScrollPane({
                    autoReinitialise: true,
                    autoReinitialiseDelay: 100
                });
                var api = $(this).data('jsp'),
                        throttleTimeout;
                $(window).bind('resize', function() {
                    if (!throttleTimeout) {
                        throttleTimeout = setTimeout(function() {
                            api.reinitialise();
                            throttleTimeout = null;
                        }, 50);
                    }
                });
            });
        }

        ///////////////////////////////////////////////////////////
        // CALENDAR
        

        ///////////////////////////////////////////////////////////
        // CAROUSEL WIDGET
        $('.carousel-widget').carousel({
            interval: 4000
        });

        $('.carousel-widget-2').carousel({
            interval: 6000
        });

        ///////////////////////////////////////////////////////////
        // DATATABLES
        $('#example1').DataTable({
            responsive: true,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
			"order": [[ 0, "desc" ]]
        });
		 $('#example2').DataTable({
            responsive: true,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
        });
		$('#example3').DataTable({
            responsive: true,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
        });

      

      


    });
</script>
<!-- End Page Scripts -->
</section>

<div class="main-backdrop"><!-- --></div>

</body>
</html>