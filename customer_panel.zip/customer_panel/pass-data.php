<?php
include('include/config.php');

if ( !defined( 'SQLSRV_FETCH_ASSOC' ) )
  define( 'SQLSRV_FETCH_ASSOC', 2 );
if( isset( $_POST['name'] ) )
{

$name = $_POST['name'];
$selectdata = " SELECT *FROM [cmsDB].[dbo].[creda_benificiary_tbl] WHERE [reg_no] = '$name'  ";
	$params=array();
	$options=array("Scrollable" => SQLSRV_CURSOR_KEYSET);
	$query21=sqlsrv_query($con,$selectdata,$params,$options);
	$rowcheck=sqlsrv_fetch_array($query21,SQLSRV_FETCH_ASSOC);
	

	
	
}




 
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<div class="row">
								<h4>Personal Details</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Registration Number</label>
                                        <input type="text" class="form-control" placeholder="Registration Number" id="reg_no"  name="reg_no" value="<?php echo $rowcheck['reg_no'] ?>" readonly>
                                    </div>
									
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Beneficiary Name</label>
                                        <input type="text" class="form-control" placeholder="Full Name" name="bname" value="<?php echo $rowcheck['beneficiary_name'] ?>"  autofocus>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Father/Husband Name</label>
                                        <input type="text" class="form-control" placeholder="Father Name" value="<?php echo $rowcheck['beneficiary_fname'] ?>"  name="bfname">
                                    </div>
                                </div>
                                
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Contact Number</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['contact_no'] ?>" maxlength="10" name="contactno" id="contact_no"  placeholder="Contact no"  autofocus>
                                    </div>
								
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Adhar Number</label>
                                        <input type="text" class="form-control" maxlength="12" value="<?php echo $rowcheck['adhar_no'] ?>" placeholder="Adhar No" name="adhar_no" id="adhar_no"   autofocus>
                                    </div>
								
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Beneficiary Category</label>
                                       <select name="category" class="form-control">
						<option value="<?php echo $rowcheck['beneficiary_category'] ?>"><?php echo $rowcheck['beneficiary_category'] ?></option>
						<?php 

$querycat =sqlsrv_query($con,"SELECT * FROM [cmsDB].[dbo].[category_tbl]");
while($rowcat=sqlsrv_fetch_array($querycat))
{ ?>
<option value="<?php echo $rowcat['category'];?>"><?php echo $rowcat['category'];?></option>
<?php
}
?>
						</select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Select District</label>
                                      <select name="district" class="form-control">
  					<option value="<?php echo $rowcheck['district'] ?>"><?php echo $rowcheck['district'] ?></option>
					<option value="Bilaspur"> Bilaspur </option>
					<option value="Mungeli"> Mungeli </option>
</select>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Select Product Type</label>
                                        <select name="product_type" id="product_type_list" class="form-control">
 <option value="<?php echo $rowcheck['product_type'].",".$rowcheck['pump_type'].",".$rowcheck['surce_type'].",".$rowcheck['total_panel'] ?>"><?php echo $rowcheck['product_type'].",".$rowcheck['pump_type'].",".$rowcheck['surce_type'] ?></option>
						<?php 

$querycat =sqlsrv_query($con,"SELECT product_type,total_panel FROM product_type_tbl WHERE product_id = 1 ");
while($rowcat=sqlsrv_fetch_array($querycat,SQLSRV_FETCH_ASSOC))
{ ?>
<option value="<?php echo $rowcat['product_type'].",".$rowcat['total_panel']; ?>"><?php echo $rowcat['product_type']; ?></option>
<?php
}
?>

</select>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Village</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['village'] ?>" name="village" placeholder="village"  autofocus>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Address</label>
                                        <input type="text" class="form-control" placeholder="Address" value="<?php echo $rowcheck['address'] ?>" name="address"  autofocus>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Subsidy Section No</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['subsidy_sanction_no'] ?>" placeholder="Subsidy Section No" name="section_no" id="section_no"  autofocus>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Section Date</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['sanction_date']->format('Y-m-d'); ?>" placeholder="Section Date" name="sec_date" id="sec_date" autofocus>
                                    </div>
                                </div>
                            </div>
							<div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Pump Head</label>
                                        <input type="text" class="form-control" placeholder="Head" value="<?php echo $rowcheck['pump_head'] ?>"  name="head">
                                    </div>
                                </div>
                               
                            </div>
							
							
							<div class="row">
							
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="l30">Panel Type</label>
                                      <input type="text" class="form-control" placeholder="panel_type" value="<?php echo $rowcheck['panel_type'] ?>"  name="panel_type">
                                    </div>
                                </div>
                               <!-- <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="l30">Panel No 2</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 2" value="<?php echo $rowcheck['panel_no2'] ?>"  name="panel_no2">
                                    </div>
                                </div>-->
								
                            </div>
								<div class="row">
							<h4>PANEL DETAILS</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 1</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 1" value="<?php echo $rowcheck['panel_no1'] ?>"  name="panel_no1">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 2</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 2" value="<?php echo $rowcheck['panel_no2'] ?>"  name="panel_no2">
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 3</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 3" value="<?php echo $rowcheck['panel_no3'] ?>"  name="panel_no3">
                                    </div>
                                </div>
                            </div>
	<div class="row">
								
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 4</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 4" value="<?php echo $rowcheck['panel_no4'] ?>"  name="panel_no4">
                                    </div>
                                </div>
                            
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 5</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 5" value="<?php echo $rowcheck['panel_no5'] ?>"  name="panel_no5">
                                    </div>
                                </div>
		 <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 6</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 6" value="<?php echo $rowcheck['panel_no6'] ?>"  name="panel_no6">
                                    </div>
                                </div>
                            </div>
	<div class="row">
								
                               
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 7</label>
                                      <input type="text" class="form-control" placeholder="PANEL NO 7" value="<?php echo $rowcheck['panel_no7'] ?>"  name="panel_no7">
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 8</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 8" value="<?php echo $rowcheck['panel_no8'] ?>"  name="panel_no8">
                                    </div>
                                </div>
		<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 9</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 9" value="<?php echo $rowcheck['panel_no9'] ?>"  name="panel_no9">
                                    </div>
                                </div>
                            </div>
	<div class="row">
								
                                
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 10</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 10" value="<?php echo $rowcheck['panel_no10'] ?>"  name="panel_no10">
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 11</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 11" value="<?php echo $rowcheck['panel_no11'] ?>"  name="panel_no11">
                                    </div>
                                </div>
		 <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 12</label>
                                      <input type="text" class="form-control" placeholder="PANEL NO 12" value="<?php echo $rowcheck['panel_no12'] ?>"  name="panel_no12">
                                    </div>
                                </div>
                            </div>
	<div class="row">
							
                               
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 13</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 13" value="<?php echo $rowcheck['panel_no13'] ?>"  name="panel_no13">
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 14</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 14" value="<?php echo $rowcheck['panel_no14'] ?>"  name="panel_no14">
                                    </div>
                                </div>
		<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 15</label>
                                      <input type="text" class="form-control" placeholder="PANEL NO 15" value="<?php echo $rowcheck['panel_no15'] ?>"  name="panel_no15">
                                    </div>
                                </div>
                            </div>
	<div class="row">
								
                                
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 16</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 16" value="<?php echo $rowcheck['panel_no16'] ?>"  name="panel_no16">
                                    </div>
                                </div>
								
                            </div>
					//////////////////////////////////
	<div class="row">
								<h4>PUMP DETAILS</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Pump Make</label>
                                      <input type="text" class="form-control" placeholder="pump_make" value="<?php echo $rowcheck['pump_make'] ?>"  name="pump_make">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Pump Serial Number</label>
                                       <input type="text" class="form-control" placeholder="Pump Serial Number" value="<?php echo $rowcheck['pumpserial'] ?>"  name="pumpserial">
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Motor Serial Number</label>
                                        <input type="text" class="form-control" placeholder="Motor Serial Number" value="<?php echo $rowcheck['motorserial'] ?>"  name="motorserial">
                                    </div>
                                </div>
                            </div>
	///////////////////////////////////////////////////////////
	<div class="row">
								<h4>CONTROLLER DETAILS</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Controller Make</label>
                                      <input type="text" class="form-control" placeholder="controler_make" value="<?php echo $rowcheck['controler_make'] ?>"  name="controler_make">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30"> Controller Serial Number</label>
                                     <input type="text" class="form-control" placeholder="controler_srno" value="<?php echo $rowcheck['controler_srno'] ?>"  name="controler_srno">
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">RMS Number</label>
                                     <input type="text" class="form-control" placeholder="controler_rms_id" value="<?php echo $rowcheck['controler_rms_id'] ?>"  name="controler_rms_id">
                                    </div>
                                </div>
                            </div>
	
						
	
	
	////////////////////////////////////
	
							<div class="row">
								<h4>BILLINGS DETAILS</h4>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Invoice No</label>
                                     <input type="text" class="form-control" placeholder="invoice_no" value="<?php echo $rowcheck['invoice_no'] ?>"  name="invoice_no">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Invoice Date</label>
                                     <input type="text" class="form-control" placeholder="invoice_date" id="invoice_date" name="invoice_date" value="<?php echo $rowcheck['invoice_date']->format('Y-m-d'); ?>" >
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30"> Commissioning Date</label>
                                  <input type="text" class="form-control"  placeholder="Section Date" name="com_date" id="com_date" value="<?php echo $rowcheck['commissioning_date']->format('Y-m-d'); ?>">
                                    </div>
                                </div>
								
                            </div>
	
	
	
						////////////////////////////
	
	
	
	
	
	<div class="row">
								<h4>Bank Details</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Bank Name</label>
                                        <input type="text" class="form-control" placeholder="Bank Name" value="<?php echo $rowcheck['bank_name'] ?>"  name="bankname">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Account Number</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['bank_account_no'] ?>" placeholder="Account Number"  name="accountnumber">
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">IFSC CODE</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck['ifsc_code'] ?>" placeholder="IFSC CODE"  name="ifsccode">
                                    </div>
                                </div>
                            </div>

<!--	<div class="row">
								<h4>Dispatched Status</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Dispatched Status</label>
                                        <select name="dispached" class="form-control">
  					<option value="<?php echo $rowcheck['dispatch_status'] ?>"><?php echo $rowcheck['dispatch_status'] ?></option>
					<option value="Dispatched"> Dispatched </option>
					<option value="Not Dispatched"> Not Dispatched </option>
</select>
                                    </div>
                                </div>
		
							<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Download Excel</label>
										<a href="exportdata.php?cid=<?php echo $rowcheck['reg_no'];?>"><button type="button" id="exportbutton"  class="btn btn-primary width-150">Download</button></a>
										
                                    </div>
                                </div>
								
                               
                            </div>-->
	
	
							
                            
                           
                            <div class="form-actions">
                                <button type="submit" name="update"  class="btn btn-primary width-150">Update</button>
                                <button type="button" class="btn btn-default">Cancel</button>
                            </div>
	
		<script src="include/js/main.js" type="text/javascript"></script>
<script>
	
	$(document).ready(function(){  
   $.datepicker.setDefaults({  
        dateFormat: 'yy-mm-dd'   
   });  
   $(function(){  
      $("#sec_date").datepicker();
	     $("#invoice_date").datepicker();
	   $("#com_date").datepicker();
	    
   });    
  }); 
	</script>
	
	</body>
</html>