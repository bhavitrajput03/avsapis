<?php
include('include/config.php');

if ( !defined( 'SQLSRV_FETCH_ASSOC' ) )
  define( 'SQLSRV_FETCH_ASSOC', 2 );
if( isset( $_POST['name'] ) )
{

$name = $_POST['name'];
$selectdata2 = " SELECT *FROM [cmsDB].[dbo].[creda_benificiary_tbl] WHERE [reg_no] = '$name'  ";
	$params=array();
	$options=array("Scrollable" => SQLSRV_CURSOR_KEYSET);
	$query211=sqlsrv_query($con,$selectdata2,$params,$options);
	$rowcheck2=sqlsrv_fetch_array($query211,SQLSRV_FETCH_ASSOC);
	
	
	
}




 
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<div class="row">
								<h4>Personal Details</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Registration Number</label>
                                        <input type="text" class="form-control" placeholder="Registration Number" id="reg_no"  name="reg_no" value="<?php echo $rowcheck2['reg_no'] ?>" readonly>
                                    </div>
									
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Beneficiary Name</label>
                                        <input type="text" class="form-control" placeholder="Full Name" name="bname" value="<?php echo $rowcheck2['beneficiary_name'] ?>"  readonly>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Father/Husband Name</label>
                                        <input type="text" class="form-control" placeholder="Father Name" value="<?php echo $rowcheck2['beneficiary_fname'] ?>"  name="bfname" readonly>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Contact Number</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck2['contact_no'] ?>" maxlength="10" name="contactno" id="contact_no"  placeholder="Contact no"  readonly>
                                    </div>
								
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Adhar Number</label>
                                        <input type="text" class="form-control" maxlength="12" value="<?php echo $rowcheck2['adhar_no'] ?>" placeholder="Adhar No" name="adhar_no" id="adhar_no"  readonly>
                                    </div>
								
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Beneficiary Category</label>
                                       <select name="category" class="form-control" readonly>
						<option value="<?php echo $rowcheck['beneficiary_category'] ?>"><?php echo $rowcheck2['beneficiary_category'] ?></option>
						
						</select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Select District</label>
                                      <select name="district" class="form-control" readonly>
  					<option value="<?php echo $rowcheck2['district'] ?>"><?php echo $rowcheck['district'] ?></option>
					
</select>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Select Product Type</label>
                                        <select name="product_type" id="product_type_list" class="form-control" readonly>
 <option value="<?php echo $rowcheck2['product_type'].",".$rowcheck2['pump_type'].",".$rowcheck2['surce_type'].",".$rowcheck2['total_panel'] ?>"><?php echo $rowcheck2['product_type'].",".$rowcheck2['pump_type'].",".$rowcheck2['surce_type'] ?></option>
						

</select>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Village</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck2['village'] ?>" name="village" placeholder="village"  readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Address</label>
                                        <input type="text" class="form-control" placeholder="Address" value="<?php echo $rowcheck2['address'] ?>" name="address"  readonly>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Subsidy Section No</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck2['subsidy_sanction_no'] ?>" placeholder="Subsidy Section No" name="section_no" id="section_no"  readonly>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Section Date</label>
                                        <input type="text" class="form-control" value="<?php echo $rowcheck2['sanction_date']->format('Y-m-d'); ?>" placeholder="Section Date" name="sec_date" id="sec_date" readonly>
                                    </div>
                                </div>
                            </div>
							<div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Pump Head</label>
             <input type="text" class="form-control" placeholder="Head" value="<?php echo $rowcheck2['pump_head'] ?>"  name="head" readonly>
                                    </div>
                                </div>
                               
                            </div>
							
							
							<div class="row">
							
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="l30">Panel Type</label>
                                      <input type="text" class="form-control" placeholder="panel_type" value="<?php echo $rowcheck2['panel_type'] ?>"  name="panel_type" readonly>
                                    </div>
                                </div>
                              
								
                            </div>
								<div class="row">
							<h4>PANEL DETAILS</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 1</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 1" value="<?php echo $rowcheck2['panel_no1'] ?>"  name="panel_no1" readonly>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 2</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 2" value="<?php echo $rowcheck2['panel_no2'] ?>"  name="panel_no2" readonly>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 3</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 3" value="<?php echo $rowcheck2['panel_no3'] ?>"  name="panel_no3" readonly>
                                    </div>
                                </div>
                            </div>
	<div class="row">
								
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 4</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 4" value="<?php echo $rowcheck2['panel_no4'] ?>"  name="panel_no4" readonly>
                                    </div>
                                </div>
                            
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 5</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 5" value="<?php echo $rowcheck2['panel_no5'] ?>"  name="panel_no5" readonly>
                                    </div>
                                </div>
		 <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 6</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 6" value="<?php echo $rowcheck2['panel_no6'] ?>"  name="panel_no6" readonly>
                                    </div>
                                </div>
                            </div>
	<div class="row">
								
                               
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 7</label>
                                      <input type="text" class="form-control" placeholder="PANEL NO 7" value="<?php echo $rowcheck2['panel_no7'] ?>"  name="panel_no7" readonly>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 8</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 8" value="<?php echo $rowcheck2['panel_no8'] ?>"  name="panel_no8" readonly>
                                    </div>
                                </div>
		<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 9</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 9" value="<?php echo $rowcheck2['panel_no9'] ?>"  name="panel_no9" readonly>
                                    </div>
                                </div>
                            </div>
	<div class="row">
								
                                
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 10</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 10" value="<?php echo $rowcheck2['panel_no10'] ?>"  name="panel_no10" readonly>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 11</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 11" value="<?php echo $rowcheck2['panel_no11'] ?>"  name="panel_no11" readonly>
                                    </div>
                                </div>
		 <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 12</label>
                                      <input type="text" class="form-control" placeholder="PANEL NO 12" value="<?php echo $rowcheck2['panel_no12'] ?>"  name="panel_no12" readonly>
                                    </div>
                                </div>
                            </div>
	<div class="row">
							
                               
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 13</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 13" value="<?php echo $rowcheck2['panel_no13'] ?>"  name="panel_no13" readonly>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 14</label>
                                        <input type="text" class="form-control" placeholder="PANEL NO 14" value="<?php echo $rowcheck2['panel_no14'] ?>"  name="panel_no14" readonly>
                                    </div>
                                </div>
		<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 15</label>
                                      <input type="text" class="form-control" placeholder="PANEL NO 15" value="<?php echo $rowcheck2['panel_no15'] ?>"  name="panel_no15" readonly>
                                    </div>
                                </div>
                            </div>
	<div class="row">
								
                                
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Panel No 16</label>
                                       <input type="text" class="form-control" placeholder="PANEL NO 16" value="<?php echo $rowcheck2['panel_no16'] ?>"  name="panel_no16" readonly>
                                    </div>
                                </div>
								
                            </div>
					//////////////////////////////////
	<div class="row">
								<h4>PUMP DETAILS</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Pump Make</label>
                                      <input type="text" class="form-control" placeholder="pump_make" value="<?php echo $rowcheck2['pump_make'] ?>"  name="pump_make" readonly>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Pump Serial Number</label>
                                       <input type="text" class="form-control" placeholder="Pump Serial Number" value="<?php echo $rowcheck2['pumpserial'] ?>"  name="pumpserial" readonly>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Motor Serial Number</label>
                                        <input type="text" class="form-control" placeholder="Motor Serial Number" value="<?php echo $rowcheck2['motorserial'] ?>"  name="motorserial" readonly>
                                    </div>
                                </div>
                            </div>
	///////////////////////////////////////////////////////////
	<div class="row">
								<h4>CONTROLLER DETAILS</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Controller Make</label>
                                      <input type="text" class="form-control" placeholder="controler_make" value="<?php echo $rowcheck2['controler_make'] ?>"  name="controler_make" readonly>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30"> Controller Serial Number</label>
                                     <input type="text" class="form-control" placeholder="controler_srno" value="<?php echo $rowcheck2['controler_srno'] ?>"  name="controler_srno" readonly>
                                    </div>
                                </div>
								<div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">RMS Number</label>
                                     <input type="text" class="form-control" placeholder="controler_rms_id" value="<?php echo $rowcheck2['controler_rms_id'] ?>"  name="controler_rms_id" readonly>
                                    </div>
                                </div>
                            </div>
	
						
	
	
	////////////////////////////////////
	
							
	
	
	
						////////////////////////////
	
	
	
	
	


<div class="row">
								<h4>Registration Number whose to be changed</h4>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="l30">Registration Number</label>
                                       <input type="text" class="form-control" placeholder="Registration Number" id="reg_nonew"  name="reg_nonew" onBlur="reg_noAvailability2()" >
                                    </div>
									<span id="register_availability_status2" style="font-size:12px;"></span>
									
                                </div>
		
							
								
                               
                            </div>
	
	
							
                            
                           
                            <div class="form-actions">
                                <button type="submit" name="update"  class="btn btn-primary width-150">Update</button>
                                <button type="button" class="btn btn-default">Cancel</button>
                            </div>
	
		<script src="include/js/main.js" type="text/javascript"></script>
<script>
	
	$(document).ready(function(){  
   $.datepicker.setDefaults({  
        dateFormat: 'yy-mm-dd'   
   });  
   $(function(){  
      $("#sec_date").datepicker();
	    
	    
   });    
  }); 
	</script>
	
	</body>
</html>